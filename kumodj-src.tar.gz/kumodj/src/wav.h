/* wav.h — minimal WAV reader (PCM 16/24/32-bit, float32) → mono float.
 * Used by the --wav developer option and tools/beattest. */
#ifndef KD_WAV_H
#define KD_WAV_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef KD_FOPEN
#define KD_FOPEN fopen
#endif

static unsigned wav_u32(const unsigned char *p) { return p[0] | p[1] << 8 | p[2] << 16 | (unsigned)p[3] << 24; }

static float *wav_load(const char *path, int *frames, int *rate) {
    FILE *f = KD_FOPEN(path, "rb");
    unsigned char h[12], ch[8], fmt[40];
    int fmtTag = 0, chans = 0, bits = 0, i, c;
    float *out = 0;
    if (!f) return 0;
    if (fread(h, 1, 12, f) != 12 || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) goto done;
    while (fread(ch, 1, 8, f) == 8) {
        unsigned sz = wav_u32(ch + 4);
        if (!memcmp(ch, "fmt ", 4)) {
            if (sz < 16 || sz > sizeof fmt || fread(fmt, 1, sz, f) != sz) goto done;
            fmtTag = fmt[0] | fmt[1] << 8;
            chans = fmt[2] | fmt[3] << 8;
            *rate = (int)wav_u32(fmt + 4);
            bits = fmt[14] | fmt[15] << 8;
            if (fmtTag == 0xFFFE && sz >= 26) fmtTag = fmt[24] | fmt[25] << 8;
            if (sz & 1) fgetc(f);
        } else if (!memcmp(ch, "data", 4)) {
            int bps = bits / 8;
            unsigned char *raw;
            if (!chans || !bps || (fmtTag != 1 && fmtTag != 3)) goto done;
            raw = malloc(sz);
            if (!raw) goto done;
            sz = (unsigned)fread(raw, 1, sz, f);
            *frames = (int)(sz / (unsigned)(bps * chans));
            out = malloc(sizeof(float) * (*frames > 0 ? *frames : 1));
            for (i = 0; out && i < *frames; i++) {
                float s = 0;
                for (c = 0; c < chans; c++) {
                    const unsigned char *p = raw + ((size_t)i * chans + c) * bps;
                    if (fmtTag == 3 && bps == 4) { float v; memcpy(&v, p, 4); s += v; }
                    else if (bps == 2) s += (short)(p[0] | p[1] << 8) / 32768.f;
                    else if (bps == 3) s += ((int)((unsigned)p[0] << 8 | (unsigned)p[1] << 16 | (unsigned)p[2] << 24) >> 8) / 8388608.f;
                    else if (bps == 4) s += (int)wav_u32(p) / 2147483648.f;
                }
                out[i] = s / chans;
            }
            free(raw);
            goto done;
        } else {
            fseek(f, sz + (sz & 1), SEEK_CUR);
        }
    }
done:
    fclose(f);
    return out;
}
#endif
