/* kumodj — a tiny real-time audio-reactive VJ.
 *
 * Captures what the computer is playing (WASAPI loopback on Windows, a Core
 * Audio process tap on macOS 14.2+, the PulseAudio monitor on Linux), tracks
 * tempo and beat phase, and drives GPU shader visuals fullscreen — by default
 * on the external display.  One translation unit: this file includes the
 * platform layer for the target OS.  See README.md for building and keys. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <time.h>

#if defined(_WIN32)
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#define COBJMACROS
#include <windows.h>
#include <GL/gl.h>
#elif defined(__APPLE__)
#define GL_SILENCE_DEPRECATION
#define GL_DO_NOT_WARN_IF_MULTI_GL_VERSION_HEADERS_INCLUDED
#include <OpenGL/gl3.h>
#else
#include <GL/gl.h>
#endif

#define KD_VERSION "1.0"

/* ------------------------------------------------------------------ */
/* shared types & platform interface                                   */

typedef struct { int x, y, w, h, primary; char name[96]; } Monitor;

typedef struct {
    int monitor, windowed, style, palette, autoSwitch, bars, strobe, list, input, frames, dumpEvery, fpsCap;
    float scale, latency, gain;
    const char *shader, *device, *wav, *dump;
    double fixedDt;
} Config;

enum { EV_KEY = 1, EV_QUIT, EV_DBLCLICK, EV_MOUSE, EV_DISPLAYS };
enum { K_ENTER = 13, K_ESC = 27, K_LEFT = 0x100, K_RIGHT, K_UP, K_DOWN, K_F11, K_TAB };

typedef struct { int type, key; } Event;
static Event evq[64];
static int evh, evt;
static void ev_push(int type, int key) {
    int n = (evt + 1) & 63;
    if (n == evh) return;
    evq[evt].type = type; evq[evt].key = key;
    evt = n;
}
static int ev_pop(Event *e) {
    if (evh == evt) return 0;
    *e = evq[evh];
    evh = (evh + 1) & 63;
    return 1;
}

static void   plat_console(void);
static void   plat_args(int *argc, char ***argv);
static int    plat_init(void);
static int    plat_monitors(Monitor *m, int max);
static int    plat_open(int mon, int fullscreen);
static void   plat_place(int mon, int fullscreen);
static void   plat_pump(void);
static void   plat_drawable(int *w, int *h);
static void   plat_swap(void);
static void  *plat_glproc(const char *name);
static double plat_now(void);
static void   plat_sleep(double s);
static void   plat_cursor(int visible);
static int    plat_audio_open(const Config *c, char *desc, int len); /* sample rate, 0 = none */
static int    plat_audio_read(float *out, int max);                 /* mono samples, non-blocking */
static int    plat_audio_rate(void);
static void   plat_audio_close(void);
static void   plat_shutdown(void);
static void   plat_error(const char *msg);
static FILE  *plat_fopen(const char *path, const char *mode);

#if defined(_WIN32)
#include "plat_win32.c"
#elif defined(__APPLE__)
#include "plat_mac.m"
#else
#include "plat_x11.c"
#endif

#define KD_FOPEN plat_fopen
#include "gl.h"
#include "analysis.h"
#include "shaders.h"
#include "font.h"
#include "wav.h"

/* ------------------------------------------------------------------ */
/* state                                                               */

static Config cfg;
static Analyzer an;
static Monitor mons[16];
static int nmons, curMon, fullscreen, running = 1;

typedef struct {
    GLuint id;
    GLint res, time, mtime, seed, band, beat, hit, mix, pal;
} Prog;

#define MAXPROG (NSTYLES + 1)
static Prog progs[MAXPROG];
static const char *progName[MAXPROG];
static int nprogs, customProg = -1;
static GLuint postProg, vao, texAudio, texHud, texScene[2], fbo[2];
static GLint pu_res, pu_fx, pu_fx2, pu_hudr, pu_hudsz;
static int sceneW, sceneH, winW, winH, cur;

#define HUD_COLS 64
#define HUD_ROWS 4
#define HUD_W (HUD_COLS * 6)
#define HUD_H (HUD_ROWS * 10)
static unsigned char hudPix[HUD_W * HUD_H];
static char hudLines[HUD_ROWS][HUD_COLS + 1];

static struct {
    double t, mt, vbeat, lastAudio, lastMouse, styleStart, taps[4];
    int beatIdx, barIdx, lastSwitchBar, style, palette, autoOn, blackout, strobe, hudPinned, ntaps;
    int pendingSwitch, cursorShown, frame, audioRate;
    unsigned lastDrop;
    float groove, beatPulse, barPhase, flash, glitch, fade, hudT, msgT, seed, strobeV, fps;
    float pal[12], palT[12];
    char msg[HUD_COLS + 1], audioDesc[96];
} vj;

static float *wavData;
static int wavLen, wavPos, wavRate;
static unsigned rngState = 0x9E3779B9u;

static unsigned rnd(void) {
    rngState ^= rngState << 13; rngState ^= rngState >> 17; rngState ^= rngState << 5;
    return rngState;
}
static float rndf(void) { return (rnd() >> 8) / 16777216.f; }
static float clampf(float x, float a, float b) { return x < a ? a : x > b ? b : x; }

static void hud_msg(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(vj.msg, sizeof vj.msg, fmt, ap);
    va_end(ap);
    vj.msgT = 3.f;
    vj.hudT = fmaxf(vj.hudT, 3.f);
}

/* ------------------------------------------------------------------ */
/* GL resources                                                        */

static GLuint compile_prog(const char **parts, int n, const char *name) {
    GLuint vs = gl.CreateShader(GL_VERTEX_SHADER), fs = gl.CreateShader(GL_FRAGMENT_SHADER), p;
    const char *vsrc = SH_VERT;
    GLint ok = 0;
    char log[2048];
    gl.ShaderSource(vs, 1, &vsrc, 0);
    gl.CompileShader(vs);
    gl.ShaderSource(fs, n, parts, 0);
    gl.CompileShader(fs);
    gl.GetShaderiv(fs, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        gl.GetShaderInfoLog(fs, sizeof log, 0, log);
        fprintf(stderr, "kumodj: shader '%s' failed to compile:\n%s\n", name, log);
        gl.DeleteShader(vs); gl.DeleteShader(fs);
        return 0;
    }
    p = gl.CreateProgram();
    gl.AttachShader(p, vs);
    gl.AttachShader(p, fs);
    gl.LinkProgram(p);
    gl.DeleteShader(vs); gl.DeleteShader(fs);
    gl.GetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        gl.GetProgramInfoLog(p, sizeof log, 0, log);
        fprintf(stderr, "kumodj: shader '%s' failed to link:\n%s\n", name, log);
        gl.DeleteProgram(p);
        return 0;
    }
    return p;
}

static int add_style(const char *name, const char **parts, int n, int slot) {
    Prog *P = &progs[slot];
    GLuint pid = compile_prog(parts, n, name);
    if (!pid) return 0;
    if (P->id) gl.DeleteProgram(P->id);
    P->id = pid;
#define U(f, s) P->f = gl.GetUniformLocation(pid, s)
    U(res, "uRes"); U(time, "uTime"); U(mtime, "uMTime"); U(seed, "uSeed"); U(band, "uBand");
    U(beat, "uBeat"); U(hit, "uHit"); U(mix, "uMix"); U(pal, "uPal");
#undef U
    gl.UseProgram(pid);
    gl.Uniform1i(gl.GetUniformLocation(pid, "uSpec"), 0);
    gl.Uniform1i(gl.GetUniformLocation(pid, "uPrev"), 1);
    progName[slot] = name;
    return 1;
}

static char *read_file(const char *path) {
    FILE *f = plat_fopen(path, "rb");
    long n;
    char *s;
    if (!f) return 0;
    fseek(f, 0, SEEK_END); n = ftell(f); fseek(f, 0, SEEK_SET);
    s = malloc(n + 1);
    if (s && fread(s, 1, n, f) != (size_t)n) { free(s); s = 0; }
    if (s) s[n] = 0;
    fclose(f);
    return s;
}

/* custom style from a file: either kumodj-native (uses the prelude's uniforms and
 * writes fragColor in main) or Shadertoy-style (defines mainImage) */
static int load_custom(void) {
    static char name[40];
    const char *parts[4], *base;
    char *src = read_file(cfg.shader);
    int n = 0, ok;
    if (!src) { hud_msg("CANNOT READ SHADER FILE"); fprintf(stderr, "kumodj: cannot read %s\n", cfg.shader); return 0; }
    base = cfg.shader + strlen(cfg.shader);
    while (base > cfg.shader && base[-1] != '/' && base[-1] != '\\') base--;
    snprintf(name, sizeof name, "%.30s", base);
    parts[n++] = SH_PRELUDE;
    if (strstr(src, "mainImage")) { parts[n++] = SH_TOY_HEAD; parts[n++] = src; parts[n++] = SH_TOY_TAIL; }
    else { parts[n++] = "#line 1\n"; parts[n++] = src; }
    ok = add_style(name, parts, n, NSTYLES);
    free(src);
    if (ok) { customProg = NSTYLES; nprogs = NSTYLES + 1; }
    else hud_msg("SHADER ERROR - SEE CONSOLE");
    return ok;
}

static void make_tex(GLuint t, GLint ifmt, int w, int h, GLenum fmt, GLenum type, GLint filt) {
    glBindTexture(GL_TEXTURE_2D, t);
    glTexImage2D(GL_TEXTURE_2D, 0, ifmt, w, h, 0, fmt, type, 0);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filt);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filt == GL_NEAREST ? GL_NEAREST : GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
}

static void resize_targets(int w, int h) {
    int i;
    if (w == sceneW && h == sceneH) return;
    sceneW = w; sceneH = h;
    for (i = 0; i < 2; i++) {
        make_tex(texScene[i], GL_RGBA16F, w, h, GL_RGBA, GL_FLOAT, GL_LINEAR_MIPMAP_LINEAR);
        gl.GenerateMipmap(GL_TEXTURE_2D);
        gl.BindFramebuffer(GL_FRAMEBUFFER, fbo[i]);
        gl.FramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, texScene[i], 0);
        glClearColor(0, 0, 0, 1);
        glClear(GL_COLOR_BUFFER_BIT);
    }
    gl.BindFramebuffer(GL_FRAMEBUFFER, 0);
}

static int render_init(void) {
    const char *parts[2];
    int i;
    gl.GenVertexArrays(1, &vao);
    gl.BindVertexArray(vao);
    parts[0] = SH_POST;
    if (!(postProg = compile_prog(parts, 1, "post"))) return 0;
    pu_res = gl.GetUniformLocation(postProg, "uRes");
    pu_fx = gl.GetUniformLocation(postProg, "uFx");
    pu_fx2 = gl.GetUniformLocation(postProg, "uFx2");
    pu_hudr = gl.GetUniformLocation(postProg, "uHudR");
    pu_hudsz = gl.GetUniformLocation(postProg, "uHudSize");
    gl.UseProgram(postProg);
    gl.Uniform1i(gl.GetUniformLocation(postProg, "uScene"), 0);
    gl.Uniform1i(gl.GetUniformLocation(postProg, "uHud"), 1);
    parts[0] = SH_PRELUDE;
    for (i = 0; i < NSTYLES; i++) {
        parts[1] = STYLES[i].src;
        if (!add_style(STYLES[i].name, parts, 2, i)) return 0;
    }
    nprogs = NSTYLES;
    if (cfg.shader) load_custom();
    glGenTextures(1, &texAudio);
    make_tex(texAudio, GL_RGBA16F, AN_BINS, 2, GL_RGBA, GL_FLOAT, GL_LINEAR);
    glGenTextures(1, &texHud);
    make_tex(texHud, GL_R8, HUD_W, HUD_H, GL_RED, GL_UNSIGNED_BYTE, GL_NEAREST);
    glGenTextures(2, texScene);
    gl.GenFramebuffers(2, fbo);
    return 1;
}

/* ------------------------------------------------------------------ */
/* HUD                                                                 */

static void hud_render(void) {
    int r, i, x, y;
    memset(hudPix, 0, sizeof hudPix);
    for (r = 0; r < HUD_ROWS; r++)
        for (i = 0; hudLines[r][i] && i < HUD_COLS; i++) {
            int ch = (unsigned char)hudLines[r][i];
            if (ch >= 'a' && ch <= 'z') ch -= 32;
            if (ch < 32 || ch > 95) ch = 32;
            for (x = 0; x < 5; x++)
                for (y = 0; y < 7; y++)
                    if (FONT5x7[ch - 32][x] >> y & 1) hudPix[(r * 10 + 1 + y) * HUD_W + i * 6 + x] = 255;
        }
    glBindTexture(GL_TEXTURE_2D, texHud);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, HUD_W, HUD_H, GL_RED, GL_UNSIGNED_BYTE, hudPix);
}

static void hud_update(void) {
    static char prev[HUD_ROWS][HUD_COLS + 1];
    char bar[5] = "....";
    int pos = ((vj.beatIdx - an.downbeat) % 4 + 4) % 4;
    const char *styleName = progName[vj.style] ? progName[vj.style] : "?";
    if (vj.groove > 0.2f) bar[pos] = '#';
    snprintf(hudLines[0], HUD_COLS + 1, "KUMODJ %d/%d %s   PAL %s   %s%s%s", vj.style + 1, nprogs, styleName,
             PALETTES[vj.palette].name, vj.autoOn ? "AUTO" : "MANUAL", vj.strobe ? "  STROBE" : "",
             vj.blackout ? "  BLACKOUT" : "");
    snprintf(hudLines[1], HUD_COLS + 1, "BPM %5.1f %s  LOCK %3d%%  LAT %+dMS  GAIN %.1f  %2.0fFPS",
             60.f * an_bps(&an), bar, (int)(an.conf * 100), (int)lroundf(cfg.latency * 1000), cfg.gain, vj.fps);
    snprintf(hudLines[2], HUD_COLS + 1, "%s", vj.msgT > 0 ? vj.msg : vj.audioDesc);
    snprintf(hudLines[3], HUD_COLS + 1, "1-0 <> STYLE  C PAL  A AUTO  T TAP  []LAT  F FULL  M SCREEN");
    if (memcmp(prev, hudLines, sizeof prev)) { memcpy(prev, hudLines, sizeof prev); hud_render(); }
}

/* ------------------------------------------------------------------ */
/* director: the auto-VJ                                               */

static void set_palette(int p, int instant) {
    vj.palette = (p % NPALETTES + NPALETTES) % NPALETTES;
    memcpy(vj.palT, PALETTES[vj.palette].p, sizeof vj.palT);
    if (instant) memcpy(vj.pal, vj.palT, sizeof vj.pal);
}

static void set_style(int s) {
    vj.style = (s % nprogs + nprogs) % nprogs;
    vj.seed = rndf();
    vj.styleStart = vj.t;
    vj.lastSwitchBar = vj.barIdx;
    vj.glitch = 1.f;
    vj.hudT = fmaxf(vj.hudT, 1.5f);
}

static void auto_switch(void) {
    int s = vj.style;
    if (nprogs > 1) while (s == vj.style) s = (int)(rnd() % (unsigned)nprogs);
    set_style(s);
    if (rndf() < 0.4f) set_palette(vj.palette + 1 + (int)(rnd() % (NPALETTES - 1)), 0);
    fprintf(stderr, "kumodj: %6.1fs  %5.1f BPM  lock %3d%%  -> %s / %s\n", vj.t, 60.f * an_bps(&an), (int)(an.conf * 100),
            progName[vj.style], PALETTES[vj.palette].name);
}

static void on_beat(int bi) {
    int pos = ((bi - an.downbeat) % 4 + 4) % 4;
    if (vj.pendingSwitch) { vj.pendingSwitch = 0; auto_switch(); }
    if (pos != 0) return;
    vj.barIdx++;
    if (!vj.autoOn) return;
    if (vj.groove > 0.3f && vj.barIdx - vj.lastSwitchBar >= cfg.bars) auto_switch();
    else if (vj.barIdx % 8 == 0 && rndf() < 0.5f) set_palette(vj.palette + 1 + (int)(rnd() % (NPALETTES - 1)), 0);
}

static void tap(void) {
    double now = vj.t, iv = 0;
    int i;
    if (vj.ntaps && now - vj.taps[vj.ntaps - 1] > 2.0) vj.ntaps = 0;
    if (vj.ntaps == 4) { memmove(vj.taps, vj.taps + 1, 3 * sizeof(double)); vj.ntaps = 3; }
    vj.taps[vj.ntaps++] = now;
    if (vj.ntaps >= 2) {
        for (i = 1; i < vj.ntaps; i++) iv += vj.taps[i] - vj.taps[i - 1];
        iv /= vj.ntaps - 1;
    }
    an_tap(&an, iv, cfg.latency);
    vj.vbeat = floor(vj.vbeat + 0.5);
    if (iv > 0) hud_msg("TAP %.1f BPM", 60.0 / iv);
    else hud_msg("TAP - BEAT PHASE RESET");
}

static void vj_update(float dt) {
    float bps = an_bps(&an), frac, kick, speed, g;
    double target;
    int bi;
    vj.t += dt;
    /* beat clock: follow the analyzer's PLL, shifted by the latency lookahead */
    target = an_beat_now(&an) + cfg.latency * bps;
    vj.vbeat += dt * bps;
    if (fabs(target - vj.vbeat) > 1.0) vj.vbeat = target;
    else vj.vbeat += (target - vj.vbeat) * fminf(1.f, dt * 8.f);
    bi = (int)floor(vj.vbeat);
    if (bi > vj.beatIdx) on_beat(bi);
    vj.beatIdx = bi;
    frac = (float)(vj.vbeat - bi);
    g = an.silent ? 0.f : clampf((an.conf - 0.12f) / 0.33f, 0, 1);
    vj.groove += (g - vj.groove) * fminf(1.f, dt * 2.f);
    vj.beatPulse = expf(-frac * 6.f) * vj.groove;
    vj.barPhase = ((((bi - an.downbeat) % 4) + 4) % 4 + frac) / 4.f;

    if (an.dropCount != vj.lastDrop) {
        vj.lastDrop = an.dropCount;
        vj.flash = 1.f;
        if (vj.autoOn) vj.pendingSwitch = 1;
        hud_msg("DROP");
        fprintf(stderr, "kumodj: %6.1fs  drop\n", vj.t);
    }
    if (vj.autoOn && vj.groove < 0.3f && vj.t - vj.styleStart > 45) auto_switch();

    kick = an.kick.pulse * cfg.gain;
    speed = an.silent ? 0.12f : 0.3f + 0.9f * an.intensity + 1.8f * kick;
    vj.mt += dt * speed;
    if (vj.mt > 4096) vj.mt -= 4096;
    vj.flash *= expf(-dt / 0.18f);
    vj.glitch *= expf(-dt / 0.12f);
    vj.fade += ((vj.blackout ? 1.f : 0.f) - vj.fade) * fminf(1.f, dt * 4.f);
    /* strobe: white on the beat, never faster than ~3 Hz (photosensitivity) */
    vj.strobeV = 0;
    if (vj.strobe && vj.groove > 0.3f && frac < 0.1f && (bps < 2.8f || (bi & 1) == 0)) vj.strobeV = 0.8f;
    {
        int i;
        float k = fminf(1.f, dt * 3.f);
        for (i = 0; i < 12; i++) vj.pal[i] += (vj.palT[i] - vj.pal[i]) * k;
    }
    if (vj.hudT > 0) vj.hudT -= dt;
    if (vj.msgT > 0) vj.msgT -= dt;
}

/* ------------------------------------------------------------------ */
/* rendering                                                           */

static void upload_audio(void) {
    static float tex[AN_BINS * 2 * 4];
    float wv[AN_WAVE];
    int i;
    an_wave(&an, wv);
    for (i = 0; i < AN_BINS; i++) {
        float *p = tex + i * 4, *q = tex + (AN_BINS + i) * 4;
        p[0] = an.spec[i]; p[1] = an.peak[i]; p[2] = an.fast[i]; p[3] = 0;
        q[0] = wv[i * AN_WAVE / AN_BINS]; q[1] = q[2] = q[3] = 0;
    }
    glBindTexture(GL_TEXTURE_2D, texAudio);
    glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, AN_BINS, 2, GL_RGBA, GL_FLOAT, tex);
}

static void render(void) {
    Prog *P = &progs[vj.style];
    float gn = cfg.gain, sc = cfg.scale, hudA;
    int w, h, hs;
    plat_drawable(&w, &h);
    if (w < 1 || h < 1) return;
    winW = w; winH = h;
    if (sc <= 0) sc = h > 1080 ? 1080.f / h : 1.f;
    resize_targets((int)(w * sc + 0.5f), (int)(h * sc + 0.5f));
    upload_audio();

    /* scene pass → texScene[cur], reading the previous frame for feedback */
    gl.BindFramebuffer(GL_FRAMEBUFFER, fbo[cur]);
    glViewport(0, 0, sceneW, sceneH);
    gl.UseProgram(P->id);
    gl.Uniform2f(P->res, (float)sceneW, (float)sceneH);
    gl.Uniform1f(P->time, (float)fmod(vj.t, 4096.0));
    gl.Uniform1f(P->mtime, (float)vj.mt);
    gl.Uniform1f(P->seed, vj.seed);
    gl.Uniform4f(P->band, fminf(1, an.bandS[0] * gn), fminf(1, an.bandS[1] * gn), fminf(1, an.bandS[2] * gn),
                 fminf(1, an.bandS[3] * gn));
    gl.Uniform4f(P->beat, vj.beatPulse, (float)(vj.vbeat - floor(vj.vbeat)), vj.barPhase, (float)vj.beatIdx);
    gl.Uniform4f(P->hit, fminf(1, an.kick.pulse * gn), fminf(1, an.snare.pulse * gn), fminf(1, an.hat.pulse * gn),
                 an.drop);
    gl.Uniform4f(P->mix, an.level, an.intensity, vj.groove, (float)(vj.t - vj.styleStart));
    gl.Uniform3fv(P->pal, 4, vj.pal);
    gl.ActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texAudio);
    gl.ActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, texScene[cur ^ 1]);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glBindTexture(GL_TEXTURE_2D, texScene[cur]);
    gl.GenerateMipmap(GL_TEXTURE_2D);

    /* post pass → screen */
    hudA = vj.hudPinned ? 1.f : cfg.dump ? 0.f : clampf(vj.hudT * 2.f, 0, 1);
    if (hudA > 0) hud_update();
    hs = h / 360 > 1 ? h / 360 : 1;
    gl.BindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, w, h);
    gl.UseProgram(postProg);
    gl.Uniform2f(pu_res, (float)w, (float)h);
    gl.Uniform4f(pu_fx, (0.03f * an.kick.pulse + 0.012f * vj.beatPulse) * gn,
                 0.0015f + 0.01f * an.snare.pulse * gn + 0.02f * an.drop, 0.5f * vj.flash + vj.strobeV, vj.fade);
    gl.Uniform4f(pu_fx2, vj.glitch, (float)fmod(vj.t, 1000.0), hudA, 0.45f + 0.5f * an.bandS[0]);
    gl.Uniform4f(pu_hudr, 12.f * hs, 12.f * hs, (float)hs, 0);
    gl.Uniform2f(pu_hudsz, HUD_W, HUD_H);
    gl.ActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, texHud);
    gl.ActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texScene[cur]);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    cur ^= 1;
}

static void dump_frame(int n) {
    char path[1024];
    unsigned char *px = malloc((size_t)winW * winH * 3);
    FILE *f;
    int y;
    if (!px) return;
    snprintf(path, sizeof path, "%s%05d.ppm", cfg.dump, n);
    glPixelStorei(GL_PACK_ALIGNMENT, 1);
    glReadPixels(0, 0, winW, winH, GL_RGB, GL_UNSIGNED_BYTE, px);
    if ((f = plat_fopen(path, "wb"))) {
        fprintf(f, "P6\n%d %d\n255\n", winW, winH);
        for (y = winH - 1; y >= 0; y--) fwrite(px + (size_t)y * winW * 3, 1, (size_t)winW * 3, f);
        fclose(f);
    }
    free(px);
}

/* ------------------------------------------------------------------ */
/* audio input                                                         */

static void pump_audio(float dt) {
    static float buf[8192];
    int n, got = 0, rate;
    if (wavData) {
        int want = (int)(dt * wavRate + 0.5f);
        while (want > 0) {
            n = want < wavLen - wavPos ? want : wavLen - wavPos;
            an_feed(&an, wavData + wavPos, n);
            wavPos = (wavPos + n) % wavLen;
            want -= n;
        }
        return;
    }
    rate = plat_audio_rate();
    if (rate > 0 && rate != vj.audioRate) { vj.audioRate = rate; an_init(&an, (float)rate); }
    while ((n = plat_audio_read(buf, 8192)) > 0) { an_feed(&an, buf, n); got += n; }
    if (got) vj.lastAudio = vj.t;
    else if (vj.t - vj.lastAudio > 0.1 && vj.audioRate > 0) {
        /* no packets (e.g. WASAPI loopback while nothing plays): keep the clock running on silence */
        n = (int)fminf(dt * vj.audioRate, 8192);
        memset(buf, 0, sizeof(float) * n);
        an_feed(&an, buf, n);
    }
}

/* ------------------------------------------------------------------ */
/* input                                                               */

static void pick_monitor(int keepCurrent) {
    int i, want = cfg.monitor;
    nmons = plat_monitors(mons, 16);
    if (nmons <= 0) { nmons = 1; memset(mons, 0, sizeof mons[0]); mons[0].w = 1280; mons[0].h = 720; mons[0].primary = 1; }
    if (keepCurrent && curMon < nmons && want < 0) want = -2;
    if (want == -2) return;
    if (want >= 0 && want < nmons) { curMon = want; return; }
    curMon = 0;
    for (i = 0; i < nmons; i++) if (mons[i].primary) curMon = i;
    for (i = 0; i < nmons; i++) if (!mons[i].primary) { curMon = i; break; } /* prefer an external display */
}

static void handle_key(int k) {
    switch (k) {
    case 'q': running = 0; break;
    case K_ESC: if (fullscreen) { fullscreen = 0; plat_place(curMon, 0); } else running = 0; break;
    case 'f': case K_F11: fullscreen = !fullscreen; plat_place(curMon, fullscreen); break;
    case 'm':
        nmons = plat_monitors(mons, 16);
        if (nmons > 0) { curMon = (curMon + 1) % nmons; cfg.monitor = curMon; plat_place(curMon, fullscreen); }
        hud_msg("SCREEN %d/%d %s", curMon + 1, nmons, mons[curMon].name);
        break;
    case K_RIGHT: case ' ': set_style(vj.style + 1); break;
    case K_LEFT: set_style(vj.style - 1); break;
    case 'c': set_palette(vj.palette + 1, 0); hud_msg("PALETTE %s", PALETTES[vj.palette].name); break;
    case 'a': vj.autoOn = !vj.autoOn; vj.lastSwitchBar = vj.barIdx; hud_msg(vj.autoOn ? "AUTO VJ ON" : "AUTO VJ OFF"); break;
    case K_UP: cfg.gain = fminf(3.f, cfg.gain + 0.1f); hud_msg("GAIN %.1f", cfg.gain); break;
    case K_DOWN: cfg.gain = fmaxf(0.2f, cfg.gain - 0.1f); hud_msg("GAIN %.1f", cfg.gain); break;
    case '[': cfg.latency -= 0.01f; hud_msg("LATENCY %+dMS", (int)lroundf(cfg.latency * 1000)); break;
    case ']': cfg.latency += 0.01f; hud_msg("LATENCY %+dMS", (int)lroundf(cfg.latency * 1000)); break;
    case 't': tap(); break;
    case 'b': vj.blackout = !vj.blackout; hud_msg(vj.blackout ? "BLACKOUT" : "BLACKOUT OFF"); break;
    case 's': vj.strobe = !vj.strobe; hud_msg(vj.strobe ? "STROBE ON - PHOTOSENSITIVITY WARNING" : "STROBE OFF"); break;
    case 'h': case K_TAB: vj.hudPinned = !vj.hudPinned; vj.hudT = 0; break;
    case 'r': if (cfg.shader && load_custom()) { set_style(customProg); hud_msg("RELOADED %s", progName[customProg]); } break;
    default:
        if (k >= '0' && k <= '9') {
            int s = k == '0' ? 9 : k - '1';
            if (s < nprogs) set_style(s);
        }
    }
    if (k != 'h' && k != K_TAB) vj.hudT = fmaxf(vj.hudT, 2.5f);
}

static void handle_events(void) {
    Event e;
    plat_pump();
    while (ev_pop(&e)) {
        switch (e.type) {
        case EV_QUIT: running = 0; break;
        case EV_KEY: handle_key(e.key); break;
        case EV_DBLCLICK: fullscreen = !fullscreen; plat_place(curMon, fullscreen); break;
        case EV_MOUSE: vj.lastMouse = vj.t; if (!vj.cursorShown) { vj.cursorShown = 1; plat_cursor(1); } break;
        case EV_DISPLAYS: {
            int old = curMon;
            pick_monitor(cfg.monitor < 0 ? 0 : 1);
            if (cfg.monitor >= nmons) { cfg.monitor = -1; pick_monitor(0); }
            if (curMon != old || fullscreen) plat_place(curMon, fullscreen);
            hud_msg("DISPLAYS CHANGED - ON SCREEN %d/%d", curMon + 1, nmons);
            break;
        }
        }
    }
    if (vj.cursorShown && vj.t - vj.lastMouse > 2.0) { vj.cursorShown = 0; plat_cursor(0); }
}

/* ------------------------------------------------------------------ */
/* command line                                                        */

static void usage(void) {
    int i;
    printf("kumodj " KD_VERSION " - tiny real-time audio-reactive VJ\n\n"
           "usage: kumodj [options]\n"
           "  -m, --monitor N    display to use (1..n, see --list; default: external display if any)\n"
           "  -w, --windowed     start in a window instead of fullscreen\n"
           "  -s, --style S      start style (number or name); default random\n"
           "  -p, --palette P    colour palette (number or name)\n"
           "      --no-auto      do not switch styles automatically\n"
           "      --bars N       bars between automatic style changes (default 16)\n"
           "      --gain X       reactivity 0.2..3 (default 1)\n"
           "      --latency MS   visual lookahead to line up with your speakers (default 40)\n"
           "      --scale X      internal render scale 0.25..1 (default: <= 1080p)\n"
           "      --fps N        frame cap (default: display refresh)\n"
           "      --shader FILE  add a custom GLSL style (kumodj or Shadertoy mainImage format)\n"
           "      --strobe       enable beat strobe (photosensitivity warning)\n"
           "      --input        macOS: capture an input device instead of system audio\n"
           "      --device NAME  macOS: input device name (e.g. BlackHole), implies --input\n"
           "      --wav FILE     analyse a WAV file (silently) instead of live audio\n"
           "      --list         list displays (and input devices) and exit\n\n"
           "styles:  ");
    for (i = 0; i < NSTYLES; i++) printf("%d %s  ", i + 1, STYLES[i].name);
    printf("\npalettes:");
    for (i = 0; i < NPALETTES; i++) printf(" %s", PALETTES[i].name);
    printf("\n\nkeys: 1-0 / arrows / space = style, C palette, A auto on/off, T tap tempo,\n"
           "      [ ] latency, up/down gain, B blackout, S strobe, H hud, F fullscreen,\n"
           "      M move to next screen, R reload shader, Esc/Q quit\n");
}

static int name_index(const char *s, int n, int isStyle) {
    int i;
    char *end;
    long v = strtol(s, &end, 10);
    if (*s && !*end) return v >= 1 && v <= n ? (int)v - 1 : -1;
    for (i = 0; i < n; i++) {
        const char *nm = isStyle ? STYLES[i].name : PALETTES[i].name, *a = s;
        const char *b = nm;
        while (*a && *b && (*a | 32) == (*b | 32)) a++, b++;
        if (!*a && !*b) return i;
    }
    return -1;
}

static int parse_args(int argc, char **argv) {
    int i;
    cfg.monitor = -1; cfg.style = -1; cfg.palette = -1; cfg.autoSwitch = 1; cfg.bars = 16;
    cfg.gain = 1.f; cfg.latency = 0.04f;
    for (i = 1; i < argc; i++) {
        const char *a = argv[i], *v = i + 1 < argc ? argv[i + 1] : 0;
#define IS(s) (!strcmp(a, s))
#define NEED() do { if (!v) { fprintf(stderr, "kumodj: %s needs a value\n", a); return 0; } i++; } while (0)
        if (IS("-h") || IS("--help") || IS("/?")) { usage(); exit(0); }
        else if (IS("-m") || IS("--monitor")) { NEED(); cfg.monitor = atoi(v) - 1; }
        else if (IS("-w") || IS("--windowed")) cfg.windowed = 1;
        else if (IS("-s") || IS("--style")) {
            NEED();
            if ((cfg.style = name_index(v, NSTYLES, 1)) < 0) { fprintf(stderr, "kumodj: unknown style %s\n", v); return 0; }
        } else if (IS("-p") || IS("--palette")) {
            NEED();
            if ((cfg.palette = name_index(v, NPALETTES, 0)) < 0) { fprintf(stderr, "kumodj: unknown palette %s\n", v); return 0; }
        } else if (IS("--no-auto")) cfg.autoSwitch = 0;
        else if (IS("--bars")) { NEED(); cfg.bars = atoi(v) > 0 ? atoi(v) : 16; }
        else if (IS("--gain")) { NEED(); cfg.gain = clampf((float)atof(v), 0.2f, 3.f); }
        else if (IS("--latency")) { NEED(); cfg.latency = (float)atof(v) / 1000.f; }
        else if (IS("--scale")) { NEED(); cfg.scale = clampf((float)atof(v), 0.25f, 1.f); }
        else if (IS("--fps")) { NEED(); cfg.fpsCap = atoi(v); }
        else if (IS("--shader")) { NEED(); cfg.shader = v; }
        else if (IS("--strobe")) cfg.strobe = 1;
        else if (IS("--input")) cfg.input = 1;
        else if (IS("--device")) { NEED(); cfg.device = v; cfg.input = 1; }
        else if (IS("--wav")) { NEED(); cfg.wav = v; }
        else if (IS("--list")) cfg.list = 1;
        /* developer options: deterministic offline rendering for tests */
        else if (IS("--frames")) { NEED(); cfg.frames = atoi(v); }
        else if (IS("--dump")) { NEED(); cfg.dump = v; }
        else if (IS("--dump-every")) { NEED(); cfg.dumpEvery = atoi(v); }
        else if (IS("--fixed-dt")) { NEED(); cfg.fixedDt = atof(v); }
        else if (IS("--hud")) vj.hudPinned = 1;
        else if (IS("--seed")) { NEED(); rngState = (unsigned)strtoul(v, 0, 10) | 1; }
        else { fprintf(stderr, "kumodj: unknown option %s (try --help)\n", a); return 0; }
#undef IS
#undef NEED
    }
    return 1;
}

/* ------------------------------------------------------------------ */

int main(int argc, char **argv) {
    double last, fpsT = 0;
    int i, fpsN = 0, rate;
    char err[256];
    plat_console();
    plat_args(&argc, &argv);
    if (!parse_args(argc, argv)) return 2;
    if (rngState == 0x9E3779B9u) rngState ^= (unsigned)time(0) * 2654435761u;
    if (!plat_init()) { plat_error("kumodj: cannot initialise the window system"); return 1; }
    pick_monitor(0);
    if (cfg.list) {
        printf("displays:\n");
        for (i = 0; i < nmons; i++)
            printf("  %d: %-28s %dx%d at %d,%d%s\n", i + 1, mons[i].name, mons[i].w, mons[i].h, mons[i].x, mons[i].y,
                   mons[i].primary ? "  (primary)" : "");
        printf("default: %d\n", curMon + 1);
        plat_audio_open(&cfg, 0, -1);
        return 0;
    }
    fullscreen = !cfg.windowed;
    if (!plat_open(curMon, fullscreen) || !gl_load()) {
        plat_error("kumodj: cannot create an OpenGL 3.3 window.\nPlease update your graphics driver.");
        return 1;
    }
    if (!render_init()) { plat_error("kumodj: shader compilation failed (see console)"); return 1; }
    fprintf(stderr, "kumodj: %s | %s | screen %d/%d %s\n", (const char *)glGetString(GL_RENDERER),
            (const char *)glGetString(GL_VERSION), curMon + 1, nmons, mons[curMon].name);

    if (cfg.wav) {
        wavData = wav_load(cfg.wav, &wavLen, &wavRate);
        if (!wavData || wavLen <= 0) { snprintf(err, sizeof err, "kumodj: cannot read WAV %s", cfg.wav); plat_error(err); return 1; }
        an_init(&an, (float)wavRate);
        snprintf(vj.audioDesc, sizeof vj.audioDesc, "WAV %.50s", cfg.wav);
    } else {
        rate = plat_audio_open(&cfg, vj.audioDesc, sizeof vj.audioDesc);
        vj.audioRate = rate > 0 ? rate : 48000;
        an_init(&an, (float)vj.audioRate);
        if (rate <= 0) fprintf(stderr, "kumodj: no audio capture: %s\n", vj.audioDesc);
    }
    fprintf(stderr, "kumodj: audio: %s\n", vj.audioDesc);

    vj.autoOn = cfg.autoSwitch;
    vj.strobe = cfg.strobe;
    set_palette(cfg.palette >= 0 ? cfg.palette : (int)(rnd() % NPALETTES), 1);
    set_style(cfg.style >= 0 ? cfg.style : customProg >= 0 ? customProg : (int)(rnd() % NSTYLES));
    if (cfg.style >= 0) vj.autoOn = 0; /* an explicit style stays until A is pressed */
    vj.glitch = 0;
    vj.hudT = cfg.dump ? 0 : 6;
    vj.cursorShown = 1;
    plat_cursor(1);
    last = plat_now();

    while (running) {
        double now = plat_now(), frameStart = now;
        float dt = (float)(now - last);
        last = now;
        if (cfg.fixedDt > 0) dt = (float)cfg.fixedDt;
        dt = clampf(dt, 0, 0.1f);
        handle_events();
        pump_audio(dt);
        vj_update(dt);
        render();
        if (cfg.dump && cfg.dumpEvery > 0 && vj.frame % cfg.dumpEvery == cfg.dumpEvery - 1) dump_frame(vj.frame + 1);
        plat_swap();
        vj.frame++;
        fpsN++;
        if (now - fpsT >= 0.5) { vj.fps = (float)(fpsN / (now - fpsT)); fpsT = now; fpsN = 0; }
        if (cfg.frames && vj.frame >= cfg.frames) running = 0;
        /* pacing: vsync normally blocks in swap; guard against it being off or the window hidden */
        {
            double minFrame = cfg.fpsCap > 0 ? 1.0 / cfg.fpsCap : 1.0 / 250;
            double spent = plat_now() - frameStart;
            if (!cfg.fixedDt && spent < minFrame) plat_sleep(minFrame - spent);
        }
    }
    plat_audio_close();
    plat_shutdown();
    return 0;
}
