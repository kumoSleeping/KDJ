/* shaders.h — GLSL for kumodj.
 *
 * Every style is a fragment shader appended to SH_PRELUDE, which declares the
 * music uniforms (see the #defines: BASS, KICK, PHASE, ...), a cosine colour
 * palette pal(t), spectrum/waveform lookups and the previous frame (feedback).
 * Style bodies are written inside S(...): the C preprocessor stringifies them,
 * which also strips comments and collapses whitespace in the binary. */
#ifndef KD_SHADERS_H
#define KD_SHADERS_H
#define S(...) #__VA_ARGS__

static const char SH_VERT[] =
    "#version 330 core\n"
    "void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);gl_Position=vec4(p*2.-1.,0.,1.);}\n";

static const char SH_PRELUDE[] =
    "#version 330 core\n"
    "uniform vec2 uRes;uniform float uTime,uMTime,uSeed;uniform vec4 uBand,uBeat,uHit,uMix;uniform vec3 uPal[4];\n"
    "uniform sampler2D uSpec,uPrev;out vec4 fragColor;\n"
    "#define PI 3.14159265\n#define TAU 6.28318531\n"
    "#define BASS uBand.x\n#define LOWMID uBand.y\n#define MID uBand.z\n#define HIGH uBand.w\n"
    "#define BEAT uBeat.x\n#define PHASE uBeat.y\n#define BAR uBeat.z\n#define BEATS uBeat.w\n"
    "#define KICK uHit.x\n#define SNARE uHit.y\n#define HAT uHit.z\n#define DROP uHit.w\n"
    "#define LEVEL uMix.x\n#define ENERGY uMix.y\n#define GROOVE uMix.z\n#define STIME uMix.w\n"
    S(
vec3 pal(float t){return uPal[0]+uPal[1]*cos(TAU*(uPal[2]*t+uPal[3]));}
float spec(float x){return texture(uSpec,vec2(x,.25)).r;}
float peak(float x){return texture(uSpec,vec2(x,.25)).g;}
float fspec(float x){return texture(uSpec,vec2(x,.25)).b;}
float wave(float x){return texture(uSpec,vec2(x,.75)).r;}
vec3 prev(vec2 uv){return texture(uPrev,uv).rgb;}
mat2 rot(float a){float c=cos(a),s=sin(a);return mat2(c,s,-s,c);}
float hash1(float n){return fract(sin(n*12.9898)*43758.5453);}
float hash2(vec2 p){vec3 q=fract(p.xyx*.1031);q+=dot(q,q.yzx+33.33);return fract((q.x+q.y)*q.z);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);
 return mix(mix(hash2(i),hash2(i+vec2(1,0)),f.x),mix(hash2(i+vec2(0,1)),hash2(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float v=0.,a=.5;for(int i=0;i<5;i++){v+=a*noise(p);p=rot(.5)*p*2.02+17.1;a*=.5;}return v;}
vec2 cuv(){return (gl_FragCoord.xy-.5*uRes)/uRes.y;}
vec2 suv(){return gl_FragCoord.xy/uRes;}
vec3 prevc(vec2 c){return prev(c*vec2(uRes.y/uRes.x,1.)+.5);}
    ) "\n";

/* ---- 1: TUNNEL — polygonal neon tunnel, rings driven by spectrum bands ---- */
static const char SH_TUNNEL[] = S(
void main(){
 vec2 p=cuv();
 p*=rot(.3*sin(uMTime*.13)+.15*sin(BAR*TAU));
 p+=.07*vec2(sin(uMTime*.31),cos(uMTime*.23));
 float n=5.+mod(floor(uSeed*7.),4.);
 float sg=TAU/n;
 float rr=length(p);
 float a=atan(p.y,p.x)+uMTime*.07;
 float la=mod(a,sg)-sg*.5;
 float r=max(rr*cos(la),1e-3);
 float z=.3/r+uMTime*1.7;
 float zi=floor(z*2.), zf=fract(z*2.);
 float s=spec(fract(zi*.071)*.75+.04);
 float ring=exp(-min(zf,1.-zf)*(22.-12.*KICK));
 float edge=exp(-abs(sg*.5-abs(la))*rr*140.);
 float panel=step(.5,fract(z*.5+floor(a/sg)*.5))*step(.35,s);
 vec3 c=pal(zi*.05+uTime*.02)*ring*(.2+2.6*s*s+1.2*KICK);
 c+=pal(.5+zi*.03)*edge*(.2+1.2*HIGH);
 c+=pal(zi*.05+.25)*panel*.06*(1.+HAT*4.);
 c*=smoothstep(0.,.22,r);
 c+=pal(BAR+.3)*(.012/(rr+.012))*(.4+BEAT*1.5+BASS);
 fragColor=vec4(c,1.);
}
);

/* ---- 2: HALO — mirrored radial spectrum with zoom feedback trails ---- */
static const char SH_HALO[] = S(
void main(){
 vec2 p=cuv();
 vec3 fb=prevc(p*(.95-.025*BASS)*rot(.006+.03*SNARE));
 float r=length(p), a=atan(p.y,p.x);
 float x=abs(a)/PI;
 float nb=40.;
 float bi=floor(x*nb), bf=fract(x*nb);
 float s=spec((bi+.5)/nb*.82+.03);
 float R=.19+.03*BEAT+.035*KICK;
 float d=r-R;
 float bar=step(0.,d)*step(d,.02+s*s*.33)*smoothstep(0.,.18,bf)*smoothstep(1.,.82,bf);
 vec3 c=pal(x*.6+uTime*.04)*bar*(.5+1.2*s);
 c+=pal(.1+uTime*.04)*exp(-abs(d)*110.)*(.5+1.5*BEAT);
 float rw=R*.72+wave(x)*.045*(1.+LEVEL);
 c+=pal(.55+x)*exp(-abs(r-rw)*380.)*(.5+MID);
 fragColor=vec4(c+fb*vec3(.8,.77,.85)*smoothstep(R*.6,R*1.3,r),1.);
}
);

/* ---- 3: LIQUID — domain-warped fbm, warp depth follows the bass ---- */
static const char SH_LIQUID[] = S(
void main(){
 vec2 p=cuv()*1.7;
 float t=uMTime*.22;
 vec2 q=vec2(fbm(p+vec2(0.,t)),fbm(p+vec2(5.2,1.3)-t*.7));
 vec2 r=vec2(fbm(p+3.*q+vec2(1.7,9.2)+t*.5),fbm(p+3.*q+vec2(8.3,2.8)-t*.4));
 float f=fbm(p+(2.5+2.5*BASS)*r);
 vec3 c=pal(f*1.4+length(q)*.6+uSeed+BAR*.25);
 c*=.25+1.6*f*f+.5*BEAT*f;
 c+=pal(f+.5)*pow(max(f-.45,0.)*2.,3.)*(1.+2.*KICK);
 c+=vec3(1.)*step(.985,hash2(floor(gl_FragCoord.xy/3.)+floor(uTime*20.)))*HAT*f;
 fragColor=vec4(c,1.);
}
);

/* ---- 4: KALEIDO — kaleidoscope of spectrum-sized rings with feedback ---- */
static const char SH_KALEIDO[] = S(
void main(){
 vec2 p=cuv();
 float n=6.+2.*mod(floor(uSeed*5.)+floor(BEATS/16.),4.);
 float sg=TAU/n;
 float a=atan(p.y,p.x)+uMTime*.08, r=length(p);
 a=mod(a,sg); a=abs(a-sg*.5);
 vec2 q=vec2(cos(a),sin(a))*r;
 q*=rot(uMTime*.15);
 q+=vec2(uMTime*.2,0.);
 vec2 gi=floor(q*3.5), g=fract(q*3.5)-.5;
 float h=hash2(gi);
 float s=spec(h*.7+.04);
 float d=abs(length(g)-.18-.22*s)-.015-.04*KICK;
 vec3 c=pal(h+uTime*.05+BAR*.3)*smoothstep(.025,0.,d)*(.4+2.2*s);
 c+=pal(h+.5)*smoothstep(.02,0.,abs(g.x)*abs(g.y)-.001)*.25*HIGH;
 c*=smoothstep(1.3,.2,r)*.85+.15;
 c=max(c*1.2,prevc(p*(.975-.02*KICK)*rot(.01))*.9);
 fragColor=vec4(c,1.);
}
);

/* ---- 5: SYNTH — retro grid, striped sun, spectrum mountains ---- */
static const char SH_SYNTH[] = S(
void main(){
 vec2 p=cuv();
 float hz=-.04;
 float d=max(hz-p.y,1e-3);
 vec2 g=vec2(p.x/d*.35,.35/d+uMTime*1.4);
 vec2 w=fwidth(g);
 vec2 dl=(.5-abs(fract(g)-.5))/max(w,vec2(1e-4));
 float line=max(exp(-dl.x*.6),exp(-dl.y*.6));
 vec3 ground=pal(.85)*line*(.45+1.3*KICK+.5*BEAT)*(1.-exp(-d*10.));
 ground+=pal(.85)*.08*exp(-d*7.);
 vec2 sp=p-vec2(0.,.19);
 float sr=.3+.015*BEAT;
 float sy=sp.y/sr;
 float cut=sy>0.?1.:step(clamp(-sy,0.,1.)*.55,fract(sy*7.-uTime*.3));
 float sunm=smoothstep(.004,-.004,length(sp)-sr)*cut;
 vec3 c=mix(pal(.95),pal(.15),clamp(sy*.5+.5,0.,1.))*1.3*sunm*(.85+.4*BASS);
 c+=pal(.95)*exp(-max(length(sp)-sr,0.)*7.)*.3*(.6+BEAT);
 float mx=abs(p.x);
 float mh=hz+.02+.16*spec(mx*.45+.05)*smoothstep(.05,.8,mx)+.025*noise(vec2(p.x*7.,1.));
 float m=smoothstep(.003,-.003,p.y-mh);
 c=mix(c,vec3(.02,0.,.05)+pal(.7)*.05,m);
 c+=pal(.6)*exp(-abs(p.y-mh)*160.)*m*(.6+HIGH);
 float st=hash2(floor(p*90.));
 c+=(1.-m)*(1.-sunm)*step(.996,st)*(.4+.6*sin(uTime*3.+st*60.))*(.6+HAT);
 c+=pal(.75)*.18*(1.-m)*smoothstep(.6,0.,p.y-hz);
 c=p.y<hz?ground:c;
 c+=pal(.9)*exp(-abs(p.y-hz)*45.)*(.3+.7*BASS);
 fragColor=vec4(c,1.);
}
);

/* ---- 6: WARP — hyperspace star streaks, speed from energy and kicks ---- */
static const char SH_WARP[] = S(
void main(){
 vec2 p=cuv()*rot(uMTime*.04);
 float r=length(p), a=atan(p.y,p.x)/TAU+.5;
 vec3 c=vec3(0.);
 for(int l=0;l<3;l++){
  float fl=float(l), n=70.+fl*55.;
  float ai=floor(a*n);
  float h=hash1(ai+fl*113.1), h2=hash1(ai*1.7+fl*57.3+3.);
  float af=fract(a*n)-.5-(h2-.5)*.6;
  float z=fract(h+uMTime*(.2+h2*.2));
  float sr=z*z*1.4;
  float len=.015+(.05+.3*ENERGY+.4*KICK)*z*z;
  float dr=sr-r;
  float tail=smoothstep(len,0.,dr)*step(0.,dr+.004);
  float wd=abs(af)/n*TAU*r;
  float star=tail*smoothstep(.0015+.004*z,0.,wd)*z*step(.35,h2);
  c+=pal(h*.4+fl*.25+uTime*.02)*star*2.;
 }
 c+=pal(BAR)*.05/(r+.05)*(.3+BASS+.6*BEAT);
 fragColor=vec4(c,1.);
}
);

/* ---- 7: SCOPE — oscilloscope lines / ring with echo feedback ---- */
static const char SH_SCOPE[] = S(
float seg(vec2 p,float y0,float y1,float dx){vec2 d=vec2(dx,y1-y0);float t=clamp(dot(p,d)/dot(d,d),0.,1.);return length(p-vec2(0.,y0)-d*t);}
void main(){
 vec2 uv=suv(), p=cuv();
 float asp=uRes.x/uRes.y;
 vec3 fb=prevc(p*(.97-.01*BASS)*rot(.008*sin(uTime*.4)));
 vec3 c=vec3(0.);
 if(mod(floor(uSeed*4.),2.)<.5){
  float dx=1./256.;
  for(int i=0;i<3;i++){
   float fi=float(i)-1.;
   float g=(.32-.08*abs(fi))*(.6+.6*LEVEL);
   float off=fi*(.18+.12*BASS);
   float x0=floor(uv.x/dx-.5)*dx+dx*.5;
   float ya=wave(x0-dx)*g+off, y0=wave(x0)*g+off, y1=wave(x0+dx)*g+off, y2=wave(x0+dx*2.)*g+off;
   vec2 q=vec2((uv.x-x0)*asp,p.y);
   float d=min(seg(q,y0,y1,dx*asp),min(seg(q+vec2(dx*asp,0.),ya,y0,dx*asp),seg(q-vec2(dx*asp,0.),y1,y2,dx*asp)));
   c+=pal(uv.x*.5+fi*.2+uTime*.05)*(exp(-d*420.)*1.3+exp(-d*45.)*.15)*(.7+.8*BEAT);
  }
 }else{
  float r=length(p), a=atan(p.y,p.x);
  float x=abs(a)/PI;
  float R=.26+.05*KICK;
  float rw=R+wave(x)*.11*(.6+LEVEL);
  float d=abs(r-rw);
  c+=pal(x+uTime*.05)*(exp(-d*380.)*1.3+exp(-d*40.)*.15)*(.7+.8*BEAT);
 }
 fragColor=vec4(c+fb*vec3(.9,.86,.93)*(.93-.05*HIGH),1.);
}
);

/* ---- 8: GYROID — raymarched gyroid tunnel flight ---- */
static const char SH_GYROID[] = S(
vec2 path(float z){return vec2(sin(z*.21)*1.3,cos(z*.17)*1.1);}
float map(vec3 p){
 float g=abs(dot(sin(p*2.3),cos(p.yzx*2.3)))/2.3-.035-.05*BASS;
 return max(g,.7-length(p.xy-path(p.z)));
}
void main(){
 vec2 p=cuv()*rot(.4*sin(uMTime*.1)+BAR*.2);
 float t=uMTime*1.2;
 vec3 ro=vec3(path(t),t), ta=vec3(path(t+1.),t+1.);
 vec3 fw=normalize(ta-ro), rt=normalize(cross(vec3(0,1,0),fw)), up=cross(fw,rt);
 vec3 rd=normalize(p.x*rt+p.y*up+1.1*fw);
 float tt=0., gl=0., d=1.;
 for(int i=0;i<80;i++){
  d=map(ro+rd*tt);
  gl+=exp(-abs(d)*30.);
  if(d<.002||tt>12.)break;
  tt+=d*.8;
 }
 vec3 q=ro+rd*tt, c=vec3(0.);
 if(d<.01){
  vec2 e=vec2(.003,-.003);
  vec3 n=normalize(e.xyy*map(q+e.xyy)+e.yyx*map(q+e.yyx)+e.yxy*map(q+e.yxy)+e.xxx*map(q+e.xxx));
  float dif=max(dot(n,-rd),0.), rim=pow(1.-dif,3.);
  float band=exp(-abs(fract(q.z*.2-uMTime*.35)-.5)*16.);
  c=pal(q.z*.03+uTime*.02)*(.08+.6*dif*dif)+pal(.5+q.z*.02)*rim*(.5+1.5*HIGH);
  c+=pal(.15+BAR*.5)*band*(.5+2.*KICK);
 }
 c*=exp(-tt*.22);
 c+=pal(.6+BAR)*gl*.006*(.3+1.5*BEAT);
 fragColor=vec4(c,1.);
}
);

/* ---- 9: EQ — mirrored LED spectrum analyser with peak caps ---- */
static const char SH_EQ[] = S(
void main(){
 vec2 uv=suv();
 float nb=56., ns=28.;
 float x=abs(uv.x-.5)*2.;
 float bi=floor(x*nb), bf=fract(x*nb);
 float fx=(bi+.5)/nb*.85+.03;
 float s=spec(fx), pk=peak(fx);
 float y=abs(uv.y-.5)*2.;
 float si=floor(y*ns), sf=fract(y*ns);
 float lvl=(si+.5)/ns;
 float cell=smoothstep(.1,.22,bf)*smoothstep(.9,.78,bf)*smoothstep(.1,.25,sf)*smoothstep(.9,.75,sf);
 float on=step(lvl,s*1.05);
 vec3 col=pal(lvl*.7+x*.15+.05);
 vec3 c=col*cell*(on*(1.+.9*KICK)+.05);
 c+=vec3(1.)*cell*step(abs(si-floor(pk*ns)),.5)*step(.03,pk)*(.6+.4*BEAT);
 c+=col*.15*on*exp(-y*3.)*BASS;
 fragColor=vec4(c,1.);
}
);

/* ---- 10: CELLS — animated voronoi, cells lit by spectrum, flashing on kicks ---- */
static const char SH_CELLS[] = S(
void main(){
 vec2 p=cuv()*(3.2+.6*sin(uMTime*.1))*rot(uMTime*.03);
 vec2 ip=floor(p), fp=fract(p);
 float d1=8., d2=8.; vec2 id=vec2(0.);
 for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){
  vec2 g=vec2(i,j);
  vec2 o=vec2(hash2(ip+g),hash2(ip+g+17.3));
  o=.5+.42*sin(uMTime*.7+TAU*o);
  vec2 r=g+o-fp; float d=dot(r,r);
  if(d<d1){d2=d1;d1=d;id=ip+g;}else if(d<d2)d2=d;
 }
 float e=sqrt(d2)-sqrt(d1);
 float h=hash2(id);
 float s=spec(h*.75+.04);
 float fl=step(1.-KICK*.4,fract(h*7.13+floor(BEATS)*.37));
 vec3 c=pal(h+BAR*.25)*(.05+s*s*1.4+fl*1.2);
 c*=smoothstep(0.,.07,e)*(1.-.5*sqrt(d1));
 c+=pal(h+.5)*exp(-e*28.)*(.25+HIGH*1.4+SNARE);
 fragColor=vec4(c,1.);
}
);

/* ---- post: beat zoom, glitch, chroma, mip bloom, tone-map, vignette, HUD ---- */
static const char SH_POST[] =
    "#version 330 core\n"
    "uniform sampler2D uScene,uHud;uniform vec2 uRes,uHudSize;uniform vec4 uFx,uFx2,uHudR;out vec4 fragColor;\n"
    S(
float h1(float n){return fract(sin(n)*43758.5453);}
void main(){
 vec2 uv=gl_FragCoord.xy/uRes;
 vec2 c=(uv-.5)*(1.-uFx.x)+.5;
 if(uFx2.x>.01){
  float fr=floor(uFx2.y*24.);
  float sl=floor(uv.y*(12.+18.*h1(fr)));
  if(h1(sl*1.37+fr)<uFx2.x*.7)c.x+=(h1(sl*3.1+fr)-.5)*.25*uFx2.x;
 }
 vec2 d=(c-.5)*uFx.y;
 vec3 col=vec3(texture(uScene,c+d).r,texture(uScene,c).g,texture(uScene,c-d).b);
 vec3 bl=textureLod(uScene,c,3.).rgb*.4+textureLod(uScene,c,5.).rgb*.35+textureLod(uScene,c,6.5).rgb*.3;
 col+=bl*uFx2.w;
 col=max(col,0.);
 col=mix(col,.75+.25*(1.-exp(-(col-.75)*4.)),step(.75,col));
 col+=uFx.z;
 vec2 v=uv-.5;
 col*=1.-.55*dot(v,v);
 col+=(fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233))+uFx2.y)*43758.5453)-.5)*.025;
 col*=1.-uFx.w;
 vec2 hp=(vec2(gl_FragCoord.x,uRes.y-gl_FragCoord.y)-uHudR.xy)/uHudR.z;
 if(uFx2.z>0.&&hp.x>=-2.&&hp.y>=-2.&&hp.x<uHudSize.x+2.&&hp.y<uHudSize.y+2.){
  float t=(hp.x>=0.&&hp.y>=0.&&hp.x<uHudSize.x&&hp.y<uHudSize.y)?texelFetch(uHud,ivec2(hp),0).r:0.;
  col=mix(col,col*.25,uFx2.z*.8);
  col=mix(col,vec3(1.),t*uFx2.z);
 }
 fragColor=vec4(col,1.);
}
    );

/* user shaders written for Shadertoy (mainImage) get this wrapper;
 * iChannel0 = audio texture (FFT row + waveform row, like Shadertoy's), iChannel1 = feedback */
static const char SH_TOY_HEAD[] =
    "#define iResolution vec3(uRes,1.)\n#define iTime uTime\n#define iTimeDelta (1./60.)\n"
    "#define iFrame int(uTime*60.)\n#define iMouse vec4(0.)\n#define iChannel0 uSpec\n#define iChannel1 uPrev\n"
    "#define iDate vec4(0.)\n#define iSampleRate 48000.\n#line 1\n";
static const char SH_TOY_TAIL[] =
    "\nvoid main(){vec4 c=vec4(0.);mainImage(c,gl_FragCoord.xy);fragColor=vec4(c.rgb,1.);}\n";

static const struct { const char *name, *src; } STYLES[] = {
    { "TUNNEL", SH_TUNNEL }, { "HALO", SH_HALO }, { "LIQUID", SH_LIQUID }, { "KALEIDO", SH_KALEIDO },
    { "SYNTH", SH_SYNTH }, { "WARP", SH_WARP }, { "SCOPE", SH_SCOPE }, { "GYROID", SH_GYROID },
    { "EQ", SH_EQ }, { "CELLS", SH_CELLS },
};
#define NSTYLES ((int)(sizeof STYLES / sizeof STYLES[0]))

/* cosine palettes  col(t) = a + b*cos(2π(c*t + d)) */
static const struct { const char *name; float p[12]; } PALETTES[] = {
    { "NEON",   { .5f,.5f,.5f,   .5f,.5f,.5f,   1.f,1.f,1.f,    0.f,.33f,.67f } },
    { "SUNSET", { .5f,.5f,.5f,   .5f,.5f,.5f,   1.f,1.f,.5f,    .8f,.9f,.3f } },
    { "ICE",    { .5f,.5f,.5f,   .5f,.5f,.5f,   1.f,.7f,.4f,    0.f,.15f,.2f } },
    { "ACID",   { .5f,.5f,.5f,   .5f,.5f,.5f,   2.f,1.f,0.f,    .5f,.2f,.25f } },
    { "VAPOR",  { .8f,.5f,.4f,   .2f,.4f,.2f,   2.f,1.f,1.f,    0.f,.25f,.25f } },
    { "FIRE",   { .75f,.35f,.08f,.35f,.3f,.08f, 1.f,1.f,1.f,    0.f,.05f,.1f } },
    { "OCEAN",  { .2f,.45f,.6f,  .2f,.35f,.4f,  1.f,1.f,1.f,    .1f,.2f,.3f } },
    { "MATRIX", { .12f,.5f,.2f,  .12f,.5f,.2f,  1.f,1.f,1.f,    0.f,0.f,0.f } },
    { "MONO",   { .5f,.5f,.5f,   .5f,.5f,.5f,   1.f,1.f,1.f,    0.f,0.f,0.f } },
};
#define NPALETTES ((int)(sizeof PALETTES / sizeof PALETTES[0]))
#undef S
#endif
