/* plat_win32.c — Windows: Win32 borderless window + WGL 3.3 core context,
 * per-monitor DPI awareness, WASAPI loopback capture of the default output. */
#define COBJMACROS
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <shellapi.h>

#ifndef WGL_CONTEXT_MAJOR_VERSION_ARB
#define WGL_CONTEXT_MAJOR_VERSION_ARB 0x2091
#define WGL_CONTEXT_MINOR_VERSION_ARB 0x2092
#define WGL_CONTEXT_PROFILE_MASK_ARB 0x9126
#define WGL_CONTEXT_CORE_PROFILE_BIT_ARB 0x0001
#endif
#ifndef AUDCLNT_STREAMFLAGS_LOOPBACK
#define AUDCLNT_STREAMFLAGS_LOOPBACK 0x00020000
#endif

static const GUID kd_CLSID_MMDeviceEnumerator = { 0xBCDE0395, 0xE52F, 0x467C, { 0x8E, 0x3D, 0xC4, 0x57, 0x92, 0x91, 0x69, 0x2E } };
static const GUID kd_IID_IMMDeviceEnumerator = { 0xA95664D2, 0x9614, 0x4F35, { 0xA7, 0x46, 0xDE, 0x8D, 0xB6, 0x36, 0x17, 0xE6 } };
static const GUID kd_IID_IAudioClient = { 0x1CB9AD4C, 0xDBFA, 0x4C32, { 0xB1, 0x78, 0xC2, 0xF5, 0x68, 0xA7, 0x03, 0xB2 } };
static const GUID kd_IID_IAudioCaptureClient = { 0xC8ADBD64, 0xE71E, 0x48A0, { 0xA4, 0xDE, 0x18, 0x5C, 0x39, 0x5C, 0xD3, 0x17 } };
static const GUID kd_SUBTYPE_FLOAT = { 0x00000003, 0x0000, 0x0010, { 0x80, 0x00, 0x00, 0xAA, 0x00, 0x38, 0x9B, 0x71 } };

static HWND w_hwnd;
static HDC w_hdc;
static HGLRC w_ctx;
static HINSTANCE w_inst;
static int w_w = 1280, w_h = 720, w_hideCursor, w_mx = -1, w_my = -1;
static Monitor w_mons[16];
static int w_nmons;
static LARGE_INTEGER w_freq;
static HMODULE w_gl32;

static void plat_console(void) {
    /* GUI-subsystem exe: print to the console we were started from, if any */
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    if (h && h != INVALID_HANDLE_VALUE && GetFileType(h) != FILE_TYPE_UNKNOWN) return; /* redirected */
    if (AttachConsole(ATTACH_PARENT_PROCESS)) {
        freopen("CONOUT$", "w", stdout);
        freopen("CONOUT$", "w", stderr);
    }
}

static void plat_args(int *argc, char ***argv) {
    int n = 0, i;
    LPWSTR *wa = CommandLineToArgvW(GetCommandLineW(), &n);
    char **out;
    if (!wa) return;
    out = calloc(n + 1, sizeof(char *));
    for (i = 0; i < n; i++) {
        int len = WideCharToMultiByte(CP_UTF8, 0, wa[i], -1, 0, 0, 0, 0);
        out[i] = malloc(len);
        WideCharToMultiByte(CP_UTF8, 0, wa[i], -1, out[i], len, 0, 0);
    }
    LocalFree(wa);
    *argc = n;
    *argv = out;
}

static FILE *plat_fopen(const char *path, const char *mode) {
    wchar_t wp[1024], wm[16];
    if (!MultiByteToWideChar(CP_UTF8, 0, path, -1, wp, 1024) || !MultiByteToWideChar(CP_UTF8, 0, mode, -1, wm, 16)) return 0;
    return _wfopen(wp, wm);
}

static void plat_error(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    MessageBoxA(0, msg, "KumoDJ", MB_ICONERROR | MB_OK);
}

static double plat_now(void) {
    LARGE_INTEGER t;
    QueryPerformanceCounter(&t);
    return (double)t.QuadPart / (double)w_freq.QuadPart;
}
static void plat_sleep(double s) { if (s > 0.001) Sleep((DWORD)(s * 1000)); }

static int w_key(WPARAM vk) {
    if (vk >= 'A' && vk <= 'Z') return (int)vk + 32;
    if (vk >= '0' && vk <= '9') return (int)vk;
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9) return '0' + (int)(vk - VK_NUMPAD0);
    switch (vk) {
    case VK_ESCAPE: return K_ESC;
    case VK_RETURN: return K_ENTER;
    case VK_SPACE: return ' ';
    case VK_LEFT: return K_LEFT;
    case VK_RIGHT: return K_RIGHT;
    case VK_UP: return K_UP;
    case VK_DOWN: return K_DOWN;
    case VK_F11: return K_F11;
    case VK_TAB: return K_TAB;
    case VK_OEM_4: return '[';
    case VK_OEM_6: return ']';
    }
    return 0;
}

static LRESULT CALLBACK w_proc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_CLOSE: ev_push(EV_QUIT, 0); return 0;
    case WM_SYSKEYDOWN:
        if (wp == VK_RETURN) { ev_push(EV_KEY, 'f'); return 0; }
        if (wp == VK_F4) { ev_push(EV_QUIT, 0); return 0; }
        break;
    case WM_KEYDOWN: { int k = w_key(wp); if (k) ev_push(EV_KEY, k); return 0; }
    case WM_LBUTTONDBLCLK: ev_push(EV_DBLCLICK, 0); return 0;
    case WM_MOUSEMOVE:
        if (LOWORD(lp) != w_mx || HIWORD(lp) != w_my) { w_mx = LOWORD(lp); w_my = HIWORD(lp); ev_push(EV_MOUSE, 0); }
        return 0;
    case WM_SETCURSOR:
        if (LOWORD(lp) == HTCLIENT) { SetCursor(w_hideCursor ? 0 : LoadCursor(0, IDC_ARROW)); return TRUE; }
        break;
    case WM_SIZE: w_w = LOWORD(lp); w_h = HIWORD(lp); return 0;
    case WM_DISPLAYCHANGE: ev_push(EV_DISPLAYS, 0); break;
    case WM_ERASEBKGND: return 1;
    case WM_SYSCOMMAND:
        if ((wp & 0xFFF0) == SC_SCREENSAVE || (wp & 0xFFF0) == SC_MONITORPOWER) return 0;
        break;
    }
    return DefWindowProcW(h, m, wp, lp);
}

static int plat_init(void) {
    typedef BOOL(WINAPI * SPDAC)(HANDLE);
    SPDAC spdac = (SPDAC)(void *)GetProcAddress(GetModuleHandleW(L"user32.dll"), "SetProcessDpiAwarenessContext");
    WNDCLASSW wc;
    if (!spdac || !spdac((HANDLE)-4 /* PER_MONITOR_AWARE_V2 */)) SetProcessDPIAware();
    QueryPerformanceFrequency(&w_freq);
    w_inst = GetModuleHandleW(0);
    memset(&wc, 0, sizeof wc);
    wc.style = CS_OWNDC | CS_DBLCLKS;
    wc.lpfnWndProc = w_proc;
    wc.hInstance = w_inst;
    wc.hIcon = LoadIconW(0, (LPCWSTR)IDI_APPLICATION);
    wc.lpszClassName = L"KumoDJ";
    return RegisterClassW(&wc) != 0;
}

static BOOL CALLBACK w_mon_cb(HMONITOR hm, HDC dc, LPRECT rc, LPARAM lp) {
    MONITORINFOEXW mi;
    DISPLAY_DEVICEW dd;
    Monitor *o;
    (void)dc; (void)rc; (void)lp;
    if (w_nmons >= 16) return FALSE;
    mi.cbSize = sizeof mi;
    if (!GetMonitorInfoW(hm, (MONITORINFO *)&mi)) return TRUE;
    o = &w_mons[w_nmons++];
    o->x = mi.rcMonitor.left; o->y = mi.rcMonitor.top;
    o->w = mi.rcMonitor.right - mi.rcMonitor.left; o->h = mi.rcMonitor.bottom - mi.rcMonitor.top;
    o->primary = (mi.dwFlags & MONITORINFOF_PRIMARY) != 0;
    dd.cb = sizeof dd;
    if (EnumDisplayDevicesW(mi.szDevice, 0, &dd, 0))
        WideCharToMultiByte(CP_UTF8, 0, dd.DeviceString, -1, o->name, sizeof o->name, 0, 0);
    else
        WideCharToMultiByte(CP_UTF8, 0, mi.szDevice, -1, o->name, sizeof o->name, 0, 0);
    return TRUE;
}

static int plat_monitors(Monitor *m, int max) {
    int i, j;
    w_nmons = 0;
    EnumDisplayMonitors(0, 0, w_mon_cb, 0);
    for (i = 1; i < w_nmons; i++) /* stable order: left to right, then top to bottom */
        for (j = i; j > 0 && (w_mons[j].x < w_mons[j - 1].x || (w_mons[j].x == w_mons[j - 1].x && w_mons[j].y < w_mons[j - 1].y)); j--) {
            Monitor t = w_mons[j]; w_mons[j] = w_mons[j - 1]; w_mons[j - 1] = t;
        }
    if (w_nmons > max) w_nmons = max;
    memcpy(m, w_mons, sizeof(Monitor) * w_nmons);
    return w_nmons;
}

static void plat_place(int mon, int fs) {
    Monitor *m = &w_mons[mon >= 0 && mon < w_nmons ? mon : 0];
    if (fs) {
        SetWindowLongW(w_hwnd, GWL_STYLE, WS_POPUP | WS_VISIBLE);
        SetWindowPos(w_hwnd, m->primary ? HWND_NOTOPMOST : HWND_TOPMOST, m->x, m->y, m->w, m->h,
                     SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    } else {
        RECT r = { 0, 0, 1280, 720 };
        UINT dpi = 96;
        typedef UINT(WINAPI * GDFW)(HWND);
        GDFW gdfw = (GDFW)(void *)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");
        if (gdfw) dpi = gdfw(w_hwnd);
        r.right = MulDiv(1280, dpi, 96); r.bottom = MulDiv(720, dpi, 96);
        SetWindowLongW(w_hwnd, GWL_STYLE, WS_OVERLAPPEDWINDOW | WS_VISIBLE);
        AdjustWindowRect(&r, WS_OVERLAPPEDWINDOW, FALSE);
        SetWindowPos(w_hwnd, HWND_NOTOPMOST, m->x + (m->w - (r.right - r.left)) / 2, m->y + (m->h - (r.bottom - r.top)) / 2,
                     r.right - r.left, r.bottom - r.top, SWP_FRAMECHANGED | SWP_SHOWWINDOW);
    }
    SetForegroundWindow(w_hwnd);
}

static int plat_open(int mon, int fs) {
    typedef HGLRC(WINAPI * CCA)(HDC, HGLRC, const int *);
    typedef BOOL(WINAPI * SI)(int);
    static const int attr[] = { WGL_CONTEXT_MAJOR_VERSION_ARB, 3, WGL_CONTEXT_MINOR_VERSION_ARB, 3,
                                WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_CORE_PROFILE_BIT_ARB, 0 };
    PIXELFORMATDESCRIPTOR pfd;
    HGLRC tmp;
    CCA cca;
    SI si;
    int pf;
    w_hwnd = CreateWindowExW(0, L"KumoDJ", L"KumoDJ", WS_POPUP, 0, 0, 1280, 720, 0, 0, w_inst, 0);
    if (!w_hwnd) return 0;
    w_hdc = GetDC(w_hwnd);
    memset(&pfd, 0, sizeof pfd);
    pfd.nSize = sizeof pfd;
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 32;
    pfd.cAlphaBits = 8;
    pf = ChoosePixelFormat(w_hdc, &pfd);
    if (!pf || !SetPixelFormat(w_hdc, pf, &pfd)) return 0;
    tmp = wglCreateContext(w_hdc);
    if (!tmp || !wglMakeCurrent(w_hdc, tmp)) return 0;
    cca = (CCA)(void *)wglGetProcAddress("wglCreateContextAttribsARB");
    w_ctx = cca ? cca(w_hdc, 0, attr) : 0;
    if (w_ctx) { wglMakeCurrent(w_hdc, w_ctx); wglDeleteContext(tmp); }
    else w_ctx = tmp; /* legacy context: fine if the driver exposes GL 3.3 anyway */
    if ((si = (SI)(void *)wglGetProcAddress("wglSwapIntervalEXT"))) si(1);
    w_gl32 = GetModuleHandleW(L"opengl32.dll");
    plat_place(mon, fs);
    ShowWindow(w_hwnd, SW_SHOW);
    SetThreadExecutionState(ES_CONTINUOUS | ES_DISPLAY_REQUIRED | ES_SYSTEM_REQUIRED);
    return 1;
}

static void plat_pump(void) {
    MSG msg;
    while (PeekMessageW(&msg, 0, 0, 0, PM_REMOVE)) {
        if (msg.message == WM_QUIT) ev_push(EV_QUIT, 0);
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
}

static void plat_drawable(int *w, int *h) { *w = w_w; *h = w_h; }
static void plat_swap(void) { SwapBuffers(w_hdc); }
static void plat_cursor(int visible) {
    w_hideCursor = !visible;
    if (!visible && GetForegroundWindow() == w_hwnd) {
        POINT pt;
        RECT r;
        GetCursorPos(&pt);
        GetWindowRect(w_hwnd, &r);
        if (PtInRect(&r, pt)) SetCursor(0);
    }
}

static void *plat_glproc(const char *name) {
    void *p = (void *)wglGetProcAddress(name);
    if (!p || p == (void *)1 || p == (void *)2 || p == (void *)3 || p == (void *)-1)
        p = (void *)GetProcAddress(w_gl32, name);
    return p;
}

/* ---- WASAPI loopback: capture whatever the default output device plays ---- */
static IMMDeviceEnumerator *wa_en;
static IMMDevice *wa_dev;
static IAudioClient *wa_ac;
static IAudioCaptureClient *wa_cc;
static LPWSTR wa_id;
static int wa_ch, wa_fmt, wa_rate, wa_com;
static double wa_retry, wa_check;
static char wa_desc[96];

static void wa_close(void) {
    if (wa_ac) IAudioClient_Stop(wa_ac);
    if (wa_cc) IAudioCaptureClient_Release(wa_cc);
    if (wa_ac) IAudioClient_Release(wa_ac);
    if (wa_dev) IMMDevice_Release(wa_dev);
    if (wa_id) CoTaskMemFree(wa_id);
    wa_cc = 0; wa_ac = 0; wa_dev = 0; wa_id = 0;
}

static int wa_open(void) {
    WAVEFORMATEX *wf = 0;
    int isFloat;
    if (!wa_com) {
        if (FAILED(CoInitializeEx(0, COINIT_MULTITHREADED))) CoInitialize(0);
        wa_com = 1;
    }
    if (!wa_en && FAILED(CoCreateInstance(&kd_CLSID_MMDeviceEnumerator, 0, CLSCTX_ALL, &kd_IID_IMMDeviceEnumerator, (void **)&wa_en))) {
        snprintf(wa_desc, sizeof wa_desc, "NO AUDIO (MMDEVICE UNAVAILABLE)");
        return 0;
    }
    if (FAILED(IMMDeviceEnumerator_GetDefaultAudioEndpoint(wa_en, eRender, eConsole, &wa_dev))) {
        snprintf(wa_desc, sizeof wa_desc, "NO AUDIO OUTPUT DEVICE");
        return 0;
    }
    IMMDevice_GetId(wa_dev, &wa_id);
    if (FAILED(IMMDevice_Activate(wa_dev, &kd_IID_IAudioClient, CLSCTX_ALL, 0, (void **)&wa_ac)) ||
        FAILED(IAudioClient_GetMixFormat(wa_ac, &wf))) goto fail;
    isFloat = wf->wFormatTag == 3 /* IEEE_FLOAT */ ||
              (wf->wFormatTag == 0xFFFE && wf->cbSize >= 22 && !memcmp((BYTE *)wf + 24, &kd_SUBTYPE_FLOAT, 16));
    wa_ch = wf->nChannels;
    wa_rate = (int)wf->nSamplesPerSec;
    if (isFloat && wf->wBitsPerSample == 32) wa_fmt = 0;
    else if (wf->wBitsPerSample == 16) wa_fmt = 1;
    else if (wf->wBitsPerSample == 32) wa_fmt = 2;
    else goto fail;
    if (FAILED(IAudioClient_Initialize(wa_ac, AUDCLNT_SHAREMODE_SHARED, AUDCLNT_STREAMFLAGS_LOOPBACK, 2000000, 0, wf, 0)) ||
        FAILED(IAudioClient_GetService(wa_ac, &kd_IID_IAudioCaptureClient, (void **)&wa_cc)) ||
        FAILED(IAudioClient_Start(wa_ac))) goto fail;
    CoTaskMemFree(wf);
    snprintf(wa_desc, sizeof wa_desc, "SYSTEM AUDIO (WASAPI LOOPBACK %dHZ %dCH)", wa_rate, wa_ch);
    return 1;
fail:
    if (wf) CoTaskMemFree(wf);
    wa_close();
    snprintf(wa_desc, sizeof wa_desc, "NO AUDIO (CANNOT OPEN LOOPBACK)");
    return 0;
}

static int plat_audio_open(const Config *c, char *desc, int len) {
    (void)c;
    if (!desc) return 0;
    wa_open();
    snprintf(desc, len, "%s", wa_desc);
    return wa_cc ? wa_rate : 0;
}

static int plat_audio_rate(void) { return wa_cc ? wa_rate : 0; }

static int plat_audio_read(float *out, int max) {
    UINT32 pk = 0;
    HRESULT hr;
    int n = 0, ch;
    double now = plat_now();
    if (!wa_cc) {
        if (now < wa_retry) return 0;
        wa_retry = now + 1.0;
        if (!wa_open()) return 0;
    }
    if (now > wa_check) { /* follow changes of the default output device */
        IMMDevice *d;
        wa_check = now + 2.0;
        if (SUCCEEDED(IMMDeviceEnumerator_GetDefaultAudioEndpoint(wa_en, eRender, eConsole, &d))) {
            LPWSTR id = 0;
            int changed = SUCCEEDED(IMMDevice_GetId(d, &id)) && wa_id && lstrcmpW(id, wa_id);
            if (id) CoTaskMemFree(id);
            IMMDevice_Release(d);
            if (changed) { wa_close(); wa_retry = 0; return 0; }
        }
    }
    ch = wa_ch > 0 ? wa_ch : 1;
    while ((hr = IAudioCaptureClient_GetNextPacketSize(wa_cc, &pk)) == S_OK && pk) {
        BYTE *data;
        UINT32 fr, i;
        DWORD flags;
        int c;
        if (n + (int)pk > max) break;
        if (FAILED(hr = IAudioCaptureClient_GetBuffer(wa_cc, &data, &fr, &flags, 0, 0))) break;
        for (i = 0; i < fr; i++) {
            float s = 0;
            if (flags & AUDCLNT_BUFFERFLAGS_SILENT) s = 0;
            else if (wa_fmt == 0) for (c = 0; c < ch; c++) s += ((const float *)data)[i * ch + c];
            else if (wa_fmt == 1) for (c = 0; c < ch; c++) s += ((const short *)data)[i * ch + c] * (1.f / 32768);
            else for (c = 0; c < ch; c++) s += ((const int *)data)[i * ch + c] * (1.f / 2147483648.f);
            out[n + i] = s / ch;
        }
        n += fr;
        IAudioCaptureClient_ReleaseBuffer(wa_cc, fr);
    }
    if (FAILED(hr)) { wa_close(); wa_retry = now + 0.5; } /* device invalidated / unplugged */
    return n;
}

static void plat_audio_close(void) {
    wa_close();
    if (wa_en) IMMDeviceEnumerator_Release(wa_en);
    wa_en = 0;
}

static void plat_shutdown(void) {
    SetThreadExecutionState(ES_CONTINUOUS);
    wglMakeCurrent(0, 0);
    if (w_ctx) wglDeleteContext(w_ctx);
    if (w_hwnd) DestroyWindow(w_hwnd);
}
