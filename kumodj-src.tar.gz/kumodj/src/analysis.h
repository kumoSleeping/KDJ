/* analysis.h — music analysis for kumodj.
 *
 * Mono PCM in → log-frequency spectrum, band energies, onset pulses
 * (kick / snare / hat), tempo (onset autocorrelation), a PLL-locked beat
 * clock, downbeat estimate and breakdown→drop detection.
 * Everything runs per hop (512 samples, ~94 Hz at 48 kHz); cost is well under
 * 1% of one CPU core.  Header-only, no allocations. */
#ifndef KD_ANALYSIS_H
#define KD_ANALYSIS_H
#include <math.h>
#include <string.h>

#define AN_N      2048   /* FFT size */
#define AN_HOP    512    /* hop size */
#define AN_BINS   256    /* log-frequency bins exported to shaders */
#define AN_WAVE   256    /* waveform samples exported to shaders */
#define AN_SCOPE  2048   /* raw sample history for the waveform */
#define AN_ODF    2048   /* onset-function history (~22 s) */
#define AN_ACW    640    /* autocorrelation window (~7 s) */
#define AN_MAXLAG 400
#define AN_PI     3.14159265358979f

typedef struct {
    float mean, var, pulse, strength;
    double last;
    int armed;
    unsigned count;
} AnHit;

typedef struct {
    float sr, hopRate;            /* analysis rate (after decimation), hops per second */
    int decim, dn; float dsum;
    float ring[AN_N]; unsigned wpos; int hopc;
    float scope[AN_SCOPE]; unsigned spos; float scopePeak;
    float win[AN_N], wnorm, cs[AN_N / 2], sn[AN_N / 2];
    unsigned short rev[AN_N];
    float re[AN_N], im[AN_N], mag[AN_N / 2 + 1], lmag[AN_N / 2 + 1];
    /* spectrum */
    float bk0[AN_BINS], bk1[AN_BINS], tilt[AN_BINS];
    float spec[AN_BINS], fast[AN_BINS], peak[AN_BINS], specRef;
    /* bands: bass, low-mid, mid, high */
    int bandK[4][2]; float bandRef[4], band[4], bandS[4];
    float levelDb, levelRef, level;
    /* onsets: flux bands low (kick), snare, hat, all */
    int fluxK[4][2]; float flux[4], magRef;
    AnHit kick, snare, hat;
    /* tempo & beat */
    float odfMean, odf[AN_ODF]; unsigned nhop;
    float acf[AN_MAXLAG + 4], hist[AN_ACW + AN_MAXLAG + 4];
    int lagMin, lagMax;
    float period, pend, conf, tapHold; int pendN, locked;
    double beat; int beatIdx;
    int slotPend, slotWait, downbeat; float slot[4];
    /* dynamics */
    float bassShort, bassLong, preBass, intensity, drop;
    int bdHops, bdTotal, breakdown, silentHops, silent;
    unsigned dropCount;
} Analyzer;

static float an_clampf(float x, float a, float b) { return x < a ? a : x > b ? b : x; }

static void an_init(Analyzer *a, float rate) {
    static const float be[5] = { 25, 140, 500, 3000, 16000 };
    static const float fe[4][2] = { { 30, 150 }, { 1500, 6000 }, { 7000, 16000 }, { 30, 12000 } };
    int i, j, b, bits = 0;
    float fmin = 30, fmax, bin;
    memset(a, 0, sizeof *a);
    a->decim = 1;
    while (rate / a->decim > 60000) a->decim *= 2;
    a->sr = rate / a->decim;
    a->hopRate = a->sr / AN_HOP;
    bin = a->sr / AN_N;
    fmax = fminf(16000, a->sr * 0.45f);
    for (i = 0, a->wnorm = 0; i < AN_N; i++) {
        a->win[i] = 0.5f - 0.5f * cosf(2 * AN_PI * i / AN_N);
        a->wnorm += a->win[i];
    }
    a->wnorm = 2.f / a->wnorm;
    for (i = 0; i < AN_N / 2; i++) {
        a->cs[i] = cosf(2 * AN_PI * i / AN_N);
        a->sn[i] = sinf(2 * AN_PI * i / AN_N);
    }
    while ((1 << bits) < AN_N) bits++;
    for (i = 0; i < AN_N; i++) {
        unsigned r = 0;
        for (b = 0; b < bits; b++) if (i >> b & 1) r |= 1u << (bits - 1 - b);
        a->rev[i] = (unsigned short)r;
    }
    for (j = 0; j < AN_BINS; j++) {
        float f0 = fmin * powf(fmax / fmin, (float)j / AN_BINS);
        float f1 = fmin * powf(fmax / fmin, (float)(j + 1) / AN_BINS);
        a->bk0[j] = f0 / bin;
        a->bk1[j] = f1 / bin;
        a->tilt[j] = 3.f * log2f(sqrtf(f0 * f1) / 1000.f); /* +3 dB/oct: flatten pink-ish music */
    }
    for (b = 0; b < 4; b++) {
        a->bandK[b][0] = (int)fmaxf(1, be[b] / bin);
        a->bandK[b][1] = (int)fminf(AN_N / 2 - 1, fmaxf(a->bandK[b][0], be[b + 1] / bin));
        a->fluxK[b][0] = (int)fmaxf(1, fe[b][0] / bin);
        a->fluxK[b][1] = (int)fminf(AN_N / 2 - 1, fmaxf(a->fluxK[b][0], fe[b][1] / bin));
        a->bandRef[b] = -60;
    }
    a->specRef = -40; a->levelRef = -40; a->magRef = 1e-4f;
    a->lagMin = (int)floorf(a->hopRate * 60 / 160); /* search 78..160 BPM, faster tempi fold down */
    a->lagMax = (int)ceilf(a->hopRate * 60 / 78);
    if (a->lagMax * 4 > AN_MAXLAG) a->lagMax = AN_MAXLAG / 4;
    a->period = a->hopRate * 0.5f; /* 120 BPM until we know better */
    a->kick.armed = a->snare.armed = a->hat.armed = 1;
}

static void an_fft(Analyzer *a) {
    float *re = a->re, *im = a->im;
    int len, i, j;
    for (len = 2; len <= AN_N; len <<= 1) {
        int half = len >> 1, step = AN_N / len;
        for (i = 0; i < AN_N; i += len)
            for (j = 0; j < half; j++) {
                float wr = a->cs[j * step], wi = -a->sn[j * step];
                int u = i + j, v = u + half;
                float tr = re[v] * wr - im[v] * wi, ti = re[v] * wi + im[v] * wr;
                re[v] = re[u] - tr; im[v] = im[u] - ti;
                re[u] += tr; im[u] += ti;
            }
    }
}

/* adaptive-threshold onset trigger */
static void an_hit(AnHit *h, float x, double now, double gap, float k, float floorv) {
    float sd = sqrtf(h->var), d;
    if (h->armed && x > h->mean + k * sd + floorv && now - h->last >= gap) {
        h->armed = 0; h->last = now; h->count++;
        h->strength = an_clampf((x - h->mean) / (2.f * k * sd + 2.f * floorv), 0.3f, 1.f);
        if (h->strength > h->pulse) h->pulse = h->strength;
    }
    if (!h->armed && (x < h->mean + 0.5f * sd || now - h->last > 4 * gap)) h->armed = 1;
    d = x - h->mean;
    h->mean += 0.02f * d;
    h->var = 0.98f * (h->var + 0.02f * d * d);
}

/* onset function `back` hops ago (fractional, linear interpolation) */
static float an_odf_at(const Analyzer *a, float back) {
    int i = (int)back;
    float f = back - i;
    unsigned n = a->nhop - 1;
    return a->odf[(n - i) & (AN_ODF - 1)] * (1 - f) + a->odf[(n - i - 1) & (AN_ODF - 1)] * f;
}

static float an_acf_max(const Analyzer *a, int c, int r) {
    float m = a->acf[c];
    int i;
    for (i = c - r; i <= c + r; i++) if (a->acf[i] > m) m = a->acf[i];
    return m;
}

static void an_tempo(Analyzer *a) {
    int W = AN_ACW, L, i, best = 0, full = 1, maxL = 4 * a->lagMax + 2, n;
    float e0 = 0, bs = -1, sc[AN_MAXLAG / 4 + 2], cf, P, valley;
    if ((int)a->nhop < W + maxL + 1) { /* short history (start-up): shorter window, 2-beat comb */
        full = (int)a->nhop - (maxL + 1) >= 300;
        if (!full) maxL = 2 * a->lagMax + 1;
        W = (int)a->nhop - (maxL + 1);
        if (W < 150) return;
    }
    n = W + maxL + 1;
    /* lightly smoothed onset history, newest first */
    for (i = 0; i < n; i++) {
        unsigned t = a->nhop - 1 - i;
        a->hist[i] = 0.5f * a->odf[t & (AN_ODF - 1)] + 0.25f * (a->odf[(t - 1) & (AN_ODF - 1)] + a->odf[(t + 1) & (AN_ODF - 1)] * (i > 0));
    }
    for (i = 0; i < W; i++) e0 += a->hist[i] * a->hist[i];
    if (e0 < 1e-6f) { a->conf *= 0.8f; return; }
    for (L = a->lagMin / 4; L <= maxL; L++) {
        float s = 0;
        for (i = 0; i < W; i++) s += a->hist[i] * a->hist[i + L];
        a->acf[L] = s / e0;
    }
    /* comb over beat multiples (searching ±m/2 lags around m·L absorbs non-integer periods),
     * weighted by a broad tempo prior centred on 120 BPM */
    for (L = a->lagMin; L <= a->lagMax; L++) {
        float bpm = 60.f * a->hopRate / L, o = log2f(bpm / 120.f) / 0.9f;
        float comb = full ? (a->acf[L] + 0.5f * an_acf_max(a, 2 * L, 1) + 0.25f * an_acf_max(a, 4 * L, 2)) / 1.75f
                          : (a->acf[L] + 0.5f * an_acf_max(a, 2 * L, 1)) / 1.5f;
        sc[L - a->lagMin] = comb;
        comb *= expf(-0.5f * o * o);
        if (comb > bs) { bs = comb; best = L; }
    }
    /* confidence: beat-lag peak against the off-beat valley; a smoothly decaying
     * acf (pads, noise) has no valley below its peak */
    for (valley = 1e9f, L = best / 4; L <= 3 * best / 4; L++) if (a->acf[L] < valley) valley = a->acf[L];
    cf = an_clampf((an_acf_max(a, best, 1) - valley - 0.12f) * 2.5f, 0, 1);
    a->conf += (cf - a->conf) * 0.3f;
    P = (float)best;
    if (best > a->lagMin && best < a->lagMax) { /* parabolic refinement */
        float y0 = sc[best - 1 - a->lagMin], y1 = sc[best - a->lagMin], y2 = sc[best + 1 - a->lagMin];
        float den = y0 - 2 * y1 + y2;
        if (den < 0) P += an_clampf(0.5f * (y0 - y2) / den, -0.5f, 0.5f);
    }
    if (cf < 0.08f || a->tapHold > 0) return;
    if (!a->locked) { a->period = P; a->locked = 1; }
    else if (fabsf(P / a->period - 1) < 0.03f) a->period += (P - a->period) * 0.2f;
    else if (fabsf(P / a->pend - 1) < 0.03f) { if (++a->pendN >= 5) { a->period = P; a->pendN = 0; } }
    else { a->pend = P; a->pendN = 1; }
}

/* beat phase: comb-match the onset history against the current period, then
 * nudge the beat clock toward it (a first-order PLL). */
static void an_phase(Analyzer *a) {
    float P = a->period, sc[AN_MAXLAG / 4 + 2], bs = -1, ph, err, fr;
    int O = (int)ceilf(P), o, k, bo = 0;
    if (a->nhop < (unsigned)(6 * P + 2)) return;
    for (o = 0; o < O; o++) {
        float s = 0, w = 1;
        for (k = 0; k < 6; k++, w *= 0.8f) s += w * an_odf_at(a, o + k * P);
        sc[o] = s;
        if (s > bs) { bs = s; bo = o; }
    }
    ph = (float)bo;
    {
        float y0 = sc[(bo + O - 1) % O], y1 = sc[bo], y2 = sc[(bo + 1) % O], den = y0 - 2 * y1 + y2;
        if (den < 0) ph += an_clampf(0.5f * (y0 - y2) / den, -0.5f, 0.5f);
    }
    ph /= P; /* beats since the last beat */
    fr = (float)(a->beat - floor(a->beat));
    err = ph - fr;
    err -= floorf(err + 0.5f);
    if (a->conf > 0.1f) a->beat += err * (0.02f + 0.06f * a->conf);
}

static void an_hop(Analyzer *a) {
    int i, j, b, k;
    float magMax = 0, frameMax = -200, rms = 0, g, dt = 1.f / a->hopRate, odf;
    float dbs[AN_BINS], fl[4] = { 0, 0, 0, 0 };
    double now = a->nhop;
    unsigned w = a->wpos;

    for (i = 0; i < AN_N; i++) {
        float s = a->ring[(w + i) & (AN_N - 1)];
        if (i >= AN_N - 2 * AN_HOP) rms += s * s;
        a->re[a->rev[i]] = s * a->win[i];
        a->im[a->rev[i]] = 0;
    }
    an_fft(a);
    for (k = 0; k <= AN_N / 2; k++) {
        float m = sqrtf(a->re[k] * a->re[k] + a->im[k] * a->im[k]) * a->wnorm;
        a->mag[k] = m;
        if (m > magMax) magMax = m;
    }

    /* level */
    a->levelDb = 10.f * log10f(rms / (2 * AN_HOP) + 1e-12f);
    a->levelRef = a->levelDb > a->levelRef ? a->levelDb : fmaxf(-50, a->levelRef - 0.01f);
    a->level = an_clampf((a->levelDb - a->levelRef + 30) / 30, 0, 1);

    /* log spectrum with slow AGC (60 dB window below the running peak) */
    for (j = 0; j < AN_BINS; j++) {
        float m, k0 = a->bk0[j], k1 = a->bk1[j];
        if (k1 - k0 < 1) {
            float kc = 0.5f * (k0 + k1);
            int ki = (int)kc;
            float f = kc - ki;
            m = a->mag[ki] * (1 - f) + a->mag[ki + 1] * f;
        } else {
            int ka = (int)ceilf(k0), kb = (int)k1;
            for (m = 0, k = ka; k <= kb; k++) if (a->mag[k] > m) m = a->mag[k];
        }
        dbs[j] = 20.f * log10f(m + 1e-9f) + a->tilt[j];
        if (dbs[j] > frameMax) frameMax = dbs[j];
    }
    if (frameMax > a->specRef) a->specRef += (frameMax - a->specRef) * 0.5f;
    else a->specRef = fmaxf(-45, a->specRef - 0.012f);
    for (j = 0; j < AN_BINS; j++) {
        float v = an_clampf((dbs[j] - a->specRef + 60) / 60, 0, 1);
        v *= v;
        a->fast[j] = v > a->fast[j] ? v : a->fast[j] + (v - a->fast[j]) * 0.25f;
        a->spec[j] += (v - a->spec[j]) * (v > a->spec[j] ? 0.6f : 0.12f);
        a->peak[j] = fmaxf(v, a->peak[j] - 0.005f);
    }

    /* bands with per-band AGC (24 dB window) */
    for (b = 0; b < 4; b++) {
        float p = 0, db, v;
        for (k = a->bandK[b][0]; k <= a->bandK[b][1]; k++) p += a->mag[k] * a->mag[k];
        db = 10.f * log10f(p + 1e-12f);
        a->bandRef[b] = db > a->bandRef[b] ? db : fmaxf(-70, a->bandRef[b] - 0.01f);
        v = an_clampf((db - a->bandRef[b] + 24) / 24, 0, 1);
        a->band[b] = v;
        a->bandS[b] += (v - a->bandS[b]) * (v > a->bandS[b] ? 0.5f : 0.1f);
    }

    /* spectral flux on log-compressed magnitudes */
    a->magRef = fmaxf(fmaxf(magMax, a->magRef * 0.9985f), 1e-5f);
    g = 100.f / a->magRef;
    for (k = 1; k <= a->fluxK[3][1]; k++) {
        float lm = logf(1 + g * a->mag[k]), d = lm - a->lmag[k];
        a->lmag[k] = lm;
        if (d <= 0) continue;
        for (b = 0; b < 4; b++) if (k >= a->fluxK[b][0] && k <= a->fluxK[b][1]) fl[b] += d;
    }
    for (b = 0; b < 4; b++) a->flux[b] = fl[b] / (a->fluxK[b][1] - a->fluxK[b][0] + 1);

    an_hit(&a->kick, a->flux[0], now, a->hopRate * 0.1, 1.6f, 0.02f);
    an_hit(&a->snare, a->flux[1], now, a->hopRate * 0.1, 1.8f, 0.01f);
    an_hit(&a->hat, a->flux[2], now, a->hopRate * 0.06, 1.8f, 0.01f);
    a->kick.pulse *= expf(-dt / 0.13f);
    a->snare.pulse *= expf(-dt / 0.10f);
    a->hat.pulse *= expf(-dt / 0.06f);

    /* onset detection function for tempo: full-band flux + kick emphasis, local mean removed */
    odf = a->flux[3] + 0.25f * a->flux[0];
    a->odf[a->nhop & (AN_ODF - 1)] = fmaxf(0, odf - a->odfMean);
    a->odfMean += (odf - a->odfMean) * 0.1f;
    a->nhop++;
    if (a->tapHold > 0) a->tapHold -= dt;
    if (a->nhop % 12 == 0) an_tempo(a);

    /* beat clock */
    a->beat += 1.0 / a->period;
    an_phase(a);
    i = (int)floor(a->beat);
    if (i > a->beatIdx) { a->slotPend = i & 3; a->slotWait = 4; }
    a->beatIdx = i;
    if (a->slotWait > 0 && --a->slotWait == 0) { /* downbeat: strongest accent slot of the bar */
        float s = 0;
        for (k = 0; k < 8; k++) s = fmaxf(s, a->odf[(a->nhop - 1 - k) & (AN_ODF - 1)]);
        for (k = 0; k < 4; k++) a->slot[k] *= 0.92f;
        a->slot[a->slotPend] += s + 0.3f * a->band[0];
        for (k = 0, j = 0; k < 4; k++) if (a->slot[k] > a->slot[j]) j = k;
        if (a->slot[j] > a->slot[a->downbeat] * 1.2f) a->downbeat = j;
    }

    /* dynamics: intensity, silence, breakdown → drop */
    a->intensity += (0.55f * a->bandS[0] + 0.25f * a->level + 0.2f * a->bandS[3] - a->intensity) * dt / 1.5f;
    a->silentHops = a->levelDb < -62 ? a->silentHops + 1 : 0;
    a->silent = a->silentHops > a->hopRate * 0.7f;
    a->bassShort += (a->band[0] - a->bassShort) * dt / 0.5f;
    a->bassLong += (a->band[0] - a->bassLong) * dt / 6.f;
    a->drop *= expf(-dt / 1.2f);
    if (!a->breakdown) {
        if (a->bassShort < 0.35f * a->bassLong && a->bassLong > 0.25f) {
            if (++a->bdHops > a->hopRate * 2) { a->breakdown = 1; a->bdTotal = 0; a->preBass = a->bassLong; }
        } else a->bdHops = 0;
    } else {
        if (a->bassShort > 0.6f * a->preBass && a->kick.pulse > 0.5f) {
            a->drop = 1; a->dropCount++; a->breakdown = 0; a->bdHops = 0;
        } else if (++a->bdTotal > a->hopRate * 60) a->breakdown = 0;
    }
}

static void an_feed(Analyzer *a, const float *x, int n) {
    int i;
    for (i = 0; i < n; i++) {
        float s = x[i];
        if (a->decim > 1) {
            a->dsum += s;
            if (++a->dn < a->decim) continue;
            s = a->dsum / a->decim; a->dsum = 0; a->dn = 0;
        }
        a->ring[a->wpos++ & (AN_N - 1)] = s;
        a->scope[a->spos++ & (AN_SCOPE - 1)] = s;
        if (++a->hopc >= AN_HOP) { a->hopc = 0; an_hop(a); }
    }
}

/* beats per second of the tracked tempo */
static float an_bps(const Analyzer *a) { return a->hopRate / a->period; }

/* beat clock extrapolated to "now" (includes the partial hop) */
static double an_beat_now(const Analyzer *a) { return a->beat + (double)a->hopc / a->sr * an_bps(a); }

/* tap tempo: `interval` seconds per beat (0 = phase only); a beat is happening now */
static void an_tap(Analyzer *a, double interval, double lookahead) {
    double b;
    if (interval > 0.25 && interval < 1.5) {
        a->period = (float)(interval * a->hopRate);
        while (a->period < a->lagMin) a->period *= 2;
        while (a->period > a->lagMax) a->period *= 0.5f;
        a->locked = 1; a->tapHold = 8; a->pendN = 0;
        if (a->conf < 0.5f) a->conf = 0.5f;
    }
    b = an_beat_now(a) + lookahead * an_bps(a);
    a->beat -= b - floor(b + 0.5);
}

/* stable (zero-crossing triggered) waveform for the oscilloscope, normalised */
static void an_wave(Analyzer *a, float *out) {
    unsigned end = a->spos, start;
    int i, best = 512;
    float pk = 1e-4f, g;
    for (i = 512; i < 1024; i++) {
        float s0 = a->scope[(end - i - 1) & (AN_SCOPE - 1)], s1 = a->scope[(end - i) & (AN_SCOPE - 1)];
        if (s0 < 0 && s1 >= 0) { best = i; break; }
    }
    start = end - best;
    for (i = 0; i < 2 * AN_WAVE; i++) pk = fmaxf(pk, fabsf(a->scope[(start + i) & (AN_SCOPE - 1)]));
    a->scopePeak = fmaxf(pk, a->scopePeak * 0.97f);
    g = 0.9f / fmaxf(a->scopePeak, 0.01f);
    for (i = 0; i < AN_WAVE; i++)
        out[i] = 0.5f * g * (a->scope[(start + 2 * i) & (AN_SCOPE - 1)] + a->scope[(start + 2 * i + 1) & (AN_SCOPE - 1)]);
}

#endif
