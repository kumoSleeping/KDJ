/* plat_mac.m — macOS: Cocoa borderless window + NSOpenGL (3.2+ core) on any
 * NSScreen, system-audio capture through a Core Audio process tap (macOS 14.2+),
 * and an AudioQueue fallback for input devices (BlackHole, Loopback, mic, line-in).
 * Compiled as part of kumodj.c with `clang -x objective-c` (manual retain/release). */
#import <Cocoa/Cocoa.h>
#import <CoreAudio/CoreAudio.h>
#import <AudioToolbox/AudioToolbox.h>
#import <IOKit/pwr_mgt/IOPMLib.h>
#include <dlfcn.h>
#include <mach/mach_time.h>
#include <unistd.h>
#include "ring.h"

/* Core Audio tap keys (macOS 14.2 SDK); spelled out so older SDKs still build */
#ifndef kAudioAggregateDeviceTapListKey
#define kAudioAggregateDeviceTapListKey "taps"
#endif
#ifndef kAudioAggregateDeviceTapAutoStartKey
#define kAudioAggregateDeviceTapAutoStartKey "tapautostart"
#endif
#ifndef kAudioSubTapUIDKey
#define kAudioSubTapUIDKey "uid"
#endif
#ifndef kAudioSubTapDriftCompensationKey
#define kAudioSubTapDriftCompensationKey "drift"
#endif
#define KD_MAIN_SUBDEVICE_KEY "master" /* kAudioAggregateDeviceMainSubDeviceKey */

static NSWindow *m_win;
static NSView *m_view;
static NSOpenGLContext *m_ctx;
static NSArray *m_screens;
static id m_delegate, m_activity;
static NSSize m_size;
static mach_timebase_info_data_t m_tb;
static IOPMAssertionID m_sleep;

@interface KDWindow : NSWindow
@end
@implementation KDWindow
- (BOOL)canBecomeKeyWindow { return YES; }
- (BOOL)canBecomeMainWindow { return YES; }
@end

@interface KDView : NSView
@end
@implementation KDView
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent *)e { return YES; }
- (BOOL)isOpaque { return YES; }
- (void)keyDown:(NSEvent *)e {
    NSString *s = [e charactersIgnoringModifiers];
    unichar c;
    int k = 0;
    if ([s length] == 0) return;
    c = [s characterAtIndex:0];
    if ([e modifierFlags] & NSEventModifierFlagCommand) {
        if (c == 'q' || c == 'w') ev_push(EV_QUIT, 0);
        else if (c == 'f') ev_push(EV_KEY, 'f');
        return;
    }
    switch (c) {
    case NSLeftArrowFunctionKey: k = K_LEFT; break;
    case NSRightArrowFunctionKey: k = K_RIGHT; break;
    case NSUpArrowFunctionKey: k = K_UP; break;
    case NSDownArrowFunctionKey: k = K_DOWN; break;
    case NSF11FunctionKey: k = K_F11; break;
    case 27: k = K_ESC; break;
    case 13: case 3: k = K_ENTER; break;
    case 9: k = K_TAB; break;
    default: if (c < 128) k = (c >= 'A' && c <= 'Z') ? c + 32 : c;
    }
    if (k) ev_push(EV_KEY, k);
}
- (void)mouseDown:(NSEvent *)e { if ([e clickCount] == 2) ev_push(EV_DBLCLICK, 0); }
- (void)mouseMoved:(NSEvent *)e { ev_push(EV_MOUSE, 0); }
@end

@interface KDDelegate : NSObject <NSApplicationDelegate, NSWindowDelegate>
@end
@implementation KDDelegate
- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)app {
    ev_push(EV_QUIT, 0);
    return NSTerminateCancel;
}
- (BOOL)windowShouldClose:(NSWindow *)w {
    ev_push(EV_QUIT, 0);
    return NO;
}
- (void)screensChanged:(NSNotification *)n { ev_push(EV_DISPLAYS, 0); }
@end

static void plat_console(void) {}
static void plat_args(int *argc, char ***argv) { (void)argc; (void)argv; }
static FILE *plat_fopen(const char *p, const char *m) { return fopen(p, m); }

static void plat_error(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    if (!isatty(STDERR_FILENO)) { /* launched from Finder: say it in a dialog */
        @autoreleasepool {
            NSAlert *a = [[[NSAlert alloc] init] autorelease];
            [NSApplication sharedApplication];
            [a setMessageText:@"KumoDJ"];
            [a setInformativeText:[NSString stringWithUTF8String:msg]];
            [a runModal];
        }
    }
}

static double plat_now(void) { return (double)mach_absolute_time() * m_tb.numer / m_tb.denom * 1e-9; }
static void plat_sleep(double s) { if (s > 0) usleep((useconds_t)(s * 1e6)); }

static __attribute__((unused)) void *plat_glproc(const char *name) { return dlsym(RTLD_DEFAULT, name); }

static int plat_init(void) {
    @autoreleasepool {
        NSMenu *bar, *appMenu;
        NSMenuItem *appItem;
        mach_timebase_info(&m_tb);
        [NSApplication sharedApplication];
        m_delegate = [[KDDelegate alloc] init];
        [NSApp setDelegate:m_delegate];
        bar = [[[NSMenu alloc] init] autorelease];
        appItem = [[[NSMenuItem alloc] init] autorelease];
        appMenu = [[[NSMenu alloc] init] autorelease];
        [appMenu addItemWithTitle:@"Quit KumoDJ" action:@selector(terminate:) keyEquivalent:@"q"];
        [appItem setSubmenu:appMenu];
        [bar addItem:appItem];
        [NSApp setMainMenu:bar];
        [[NSNotificationCenter defaultCenter] addObserver:m_delegate
                                                 selector:@selector(screensChanged:)
                                                     name:NSApplicationDidChangeScreenParametersNotification
                                                   object:nil];
    }
    return 1;
}

static int plat_monitors(Monitor *m, int max) {
    int n = 0;
    @autoreleasepool {
        NSArray *all = [NSScreen screens];
        NSScreen *menuScreen = [all count] ? [all objectAtIndex:0] : nil;
        NSArray *sorted = [all sortedArrayUsingComparator:^NSComparisonResult(id a, id b) {
            NSRect fa = [(NSScreen *)a frame], fb = [(NSScreen *)b frame];
            if (fa.origin.x != fb.origin.x) return fa.origin.x < fb.origin.x ? NSOrderedAscending : NSOrderedDescending;
            if (fa.origin.y != fb.origin.y) return fa.origin.y > fb.origin.y ? NSOrderedAscending : NSOrderedDescending;
            return NSOrderedSame;
        }];
        [m_screens release];
        m_screens = [sorted retain];
        for (NSScreen *s in m_screens) {
            NSRect f = [s frame];
            CGFloat sc = [s backingScaleFactor];
            Monitor *o;
            if (n >= max) break;
            o = &m[n++];
            o->x = (int)f.origin.x; o->y = (int)f.origin.y;
            o->w = (int)(f.size.width * sc); o->h = (int)(f.size.height * sc);
            o->primary = s == menuScreen;
            snprintf(o->name, sizeof o->name, "%s", [[s localizedName] UTF8String]);
        }
    }
    return n;
}

static void plat_place(int mon, int fs) {
    @autoreleasepool {
        NSScreen *s;
        NSRect f;
        BOOL onMenuScreen;
        if (!m_screens || ![m_screens count]) return;
        s = [m_screens objectAtIndex:(mon >= 0 && mon < (int)[m_screens count]) ? (NSUInteger)mon : 0];
        f = [s frame];
        onMenuScreen = s == [[NSScreen screens] objectAtIndex:0];
        if (fs) {
            [m_win setStyleMask:NSWindowStyleMaskBorderless];
            [m_win setFrame:f display:YES];
            /* on an external display float above its menu bar; on the main one hide menu bar & dock */
            [m_win setLevel:onMenuScreen ? NSNormalWindowLevel : NSMainMenuWindowLevel + 1];
            [m_win setCollectionBehavior:NSWindowCollectionBehaviorCanJoinAllSpaces |
                                         NSWindowCollectionBehaviorFullScreenAuxiliary];
        } else {
            NSRect r = NSMakeRect(f.origin.x + (f.size.width - 1280) / 2, f.origin.y + (f.size.height - 720) / 2, 1280, 720);
            [m_win setStyleMask:NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskMiniaturizable |
                                NSWindowStyleMaskResizable];
            [m_win setLevel:NSNormalWindowLevel];
            [m_win setCollectionBehavior:NSWindowCollectionBehaviorDefault];
            [m_win setFrame:[m_win frameRectForContentRect:r] display:YES];
            [m_win setTitle:@"KumoDJ"];
        }
        [NSApp setPresentationOptions:(fs && onMenuScreen)
                                          ? (NSApplicationPresentationHideDock | NSApplicationPresentationHideMenuBar)
                                          : NSApplicationPresentationDefault];
        [m_win makeKeyAndOrderFront:nil];
        [m_win makeFirstResponder:m_view];
        [m_ctx update];
    }
}

static void plat_pump(void) {
    @autoreleasepool {
        NSEvent *e;
        while ((e = [NSApp nextEventMatchingMask:NSEventMaskAny untilDate:nil inMode:NSDefaultRunLoopMode dequeue:YES]))
            [NSApp sendEvent:e];
    }
}

static int plat_open(int mon, int fs) {
    @autoreleasepool {
        NSOpenGLPixelFormatAttribute at[] = { NSOpenGLPFAOpenGLProfile, NSOpenGLProfileVersion3_2Core,
                                              NSOpenGLPFADoubleBuffer, NSOpenGLPFAAccelerated,
                                              NSOpenGLPFAColorSize, 24, NSOpenGLPFAAlphaSize, 8, 0 };
        NSOpenGLPixelFormat *pf = [[[NSOpenGLPixelFormat alloc] initWithAttributes:at] autorelease];
        GLint one = 1;
        if (!pf) return 0;
        m_ctx = [[NSOpenGLContext alloc] initWithFormat:pf shareContext:nil];
        if (!m_ctx) return 0;
        [NSApp setActivationPolicy:NSApplicationActivationPolicyRegular];
        [NSApp finishLaunching];
        m_win = [[KDWindow alloc] initWithContentRect:NSMakeRect(0, 0, 1280, 720)
                                            styleMask:NSWindowStyleMaskBorderless
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        m_view = [[KDView alloc] initWithFrame:NSMakeRect(0, 0, 1280, 720)];
        [m_view setWantsBestResolutionOpenGLSurface:YES];
        [m_win setContentView:m_view];
        [m_win setDelegate:m_delegate];
        [m_win setAcceptsMouseMovedEvents:YES];
        [m_win setReleasedWhenClosed:NO];
        [m_win setHidesOnDeactivate:NO];
        [m_win setBackgroundColor:[NSColor blackColor]];
        plat_place(mon, fs);
        [NSApp activateIgnoringOtherApps:YES];
        plat_pump();
        [m_ctx setView:m_view];
        [m_ctx makeCurrentContext];
        [m_ctx setValues:&one forParameter:NSOpenGLContextParameterSwapInterval];
        IOPMAssertionCreateWithName(kIOPMAssertionTypePreventUserIdleDisplaySleep, kIOPMAssertionLevelOn,
                                    CFSTR("KumoDJ live visuals"), &m_sleep);
        m_activity = [[[NSProcessInfo processInfo]
            beginActivityWithOptions:NSActivityUserInitiated | NSActivityLatencyCritical
                              reason:@"live visuals"] retain];
    }
    return 1;
}

static void plat_drawable(int *w, int *h) {
    NSRect b = [m_view convertRectToBacking:[m_view bounds]];
    if (b.size.width != m_size.width || b.size.height != m_size.height) {
        m_size = b.size;
        [m_ctx update];
    }
    *w = (int)b.size.width;
    *h = (int)b.size.height;
}

static void plat_swap(void) {
    [m_ctx flushBuffer];
    if (!([m_win occlusionState] & NSWindowOcclusionStateVisible)) usleep(30000); /* hidden: don't spin */
}

static void plat_cursor(int visible) {
    if (!visible && [NSApp isActive]) [NSCursor setHiddenUntilMouseMoves:YES];
}

/* ---- audio ---- */
static AudioObjectID ma_tap, ma_agg;
static AudioDeviceIOProcID ma_proc;
static AudioQueueRef ma_q;
static int ma_rate, ma_skip;

static OSStatus ma_ioproc(AudioObjectID dev, const AudioTimeStamp *now, const AudioBufferList *in,
                          const AudioTimeStamp *inTime, AudioBufferList *out, const AudioTimeStamp *outTime, void *ud) {
    float tmp[1024];
    UInt32 nb, chans, frames, i, j, b, c;
    const AudioBuffer *b0;
    (void)dev; (void)now; (void)inTime; (void)out; (void)outTime; (void)ud;
    if (!in || in->mNumberBuffers <= (UInt32)ma_skip) return noErr;
    nb = in->mNumberBuffers - ma_skip; /* the tap's buffers follow the output device's own inputs */
    b0 = &in->mBuffers[ma_skip];
    if (!b0->mData) return noErr;
    chans = nb == 1 && b0->mNumberChannels ? b0->mNumberChannels : 1;
    frames = b0->mDataByteSize / (4 * chans);
    for (i = 0; i < frames; i += j) {
        UInt32 n = frames - i < 1024 ? frames - i : 1024;
        for (j = 0; j < n; j++) {
            float s = 0;
            if (nb == 1) {
                const float *d = (const float *)b0->mData + (size_t)(i + j) * chans;
                for (c = 0; c < chans; c++) s += d[c];
                s /= chans;
            } else {
                for (b = 0; b < nb; b++)
                    if (in->mBuffers[ma_skip + b].mData) s += ((const float *)in->mBuffers[ma_skip + b].mData)[i + j];
                s /= nb;
            }
            tmp[j] = s;
        }
        rb_push(tmp, (int)n);
    }
    return noErr;
}

static int ma_get(AudioObjectID obj, AudioObjectPropertySelector sel, AudioObjectPropertyScope scope, void *out, UInt32 size) {
    AudioObjectPropertyAddress pa = { sel, scope, 0 };
    return AudioObjectGetPropertyData(obj, &pa, 0, NULL, &size, out) == noErr;
}

static int ma_input_channels(AudioDeviceID d) {
    AudioObjectPropertyAddress pa = { kAudioDevicePropertyStreamConfiguration, kAudioObjectPropertyScopeInput, 0 };
    UInt32 sz = 0, i;
    int n = 0;
    AudioBufferList *bl;
    if (AudioObjectGetPropertyDataSize(d, &pa, 0, NULL, &sz) != noErr || !sz) return 0;
    bl = malloc(sz);
    if (bl && AudioObjectGetPropertyData(d, &pa, 0, NULL, &sz, bl) == noErr)
        for (i = 0; i < bl->mNumberBuffers; i++) n += (int)bl->mBuffers[i].mNumberChannels;
    free(bl);
    return n;
}

static int ma_input_buffers(AudioDeviceID d) {
    AudioObjectPropertyAddress pa = { kAudioDevicePropertyStreamConfiguration, kAudioObjectPropertyScopeInput, 0 };
    UInt32 sz = 0;
    int n = 0;
    AudioBufferList *bl;
    if (AudioObjectGetPropertyDataSize(d, &pa, 0, NULL, &sz) != noErr || !sz) return 0;
    bl = malloc(sz);
    if (bl && AudioObjectGetPropertyData(d, &pa, 0, NULL, &sz, bl) == noErr) n = (int)bl->mNumberBuffers;
    free(bl);
    return n;
}

static void ma_name(AudioObjectID d, char *out, int len) {
    CFStringRef s = NULL;
    out[0] = 0;
    if (ma_get(d, kAudioObjectPropertyName, kAudioObjectPropertyScopeGlobal, &s, sizeof s) && s) {
        CFStringGetCString(s, out, len, kCFStringEncodingUTF8);
        CFRelease(s);
    }
}

/* find an input-capable device whose name contains `want` (or print them all when want == NULL) */
static AudioDeviceID ma_find_input(const char *want, char *name, int len) {
    AudioObjectPropertyAddress pa = { kAudioHardwarePropertyDevices, kAudioObjectPropertyScopeGlobal, 0 };
    UInt32 sz = 0, i;
    AudioDeviceID *ids, found = 0;
    char nm[128];
    if (AudioObjectGetPropertyDataSize(kAudioObjectSystemObject, &pa, 0, NULL, &sz) != noErr || !sz) return 0;
    ids = malloc(sz);
    if (ids && AudioObjectGetPropertyData(kAudioObjectSystemObject, &pa, 0, NULL, &sz, ids) == noErr)
        for (i = 0; i < sz / sizeof(AudioDeviceID); i++) {
            if (!ma_input_channels(ids[i])) continue;
            ma_name(ids[i], nm, sizeof nm);
            if (!want) printf("  %s\n", nm);
            else if (strcasestr(nm, want)) { found = ids[i]; snprintf(name, len, "%s", nm); break; }
        }
    free(ids);
    return found;
}

static int ma_tap_open(char *desc, int len) {
    typedef OSStatus (*CreateTapFn)(id, AudioObjectID *);
    CreateTapFn createTap = (CreateTapFn)dlsym(RTLD_DEFAULT, "AudioHardwareCreateProcessTap");
    Class tapClass = NSClassFromString(@"CATapDescription");
    AudioDeviceID outDev = 0;
    CFStringRef outUID = NULL;
    NSMutableDictionary *d;
    NSString *tapUID;
    NSNumber *yes, *no;
    Float64 rate = 0;
    id td;
    if (!createTap || !tapClass) return 0; /* macOS < 14.2 */
    td = [[tapClass alloc] performSelector:@selector(initStereoGlobalTapButExcludeProcesses:) withObject:@[]];
    if (!td) return 0;
    if (createTap(td, &ma_tap) != noErr || !ma_tap) { [td release]; return 0; }
    tapUID = [[td valueForKey:@"UUID"] UUIDString];
    yes = [NSNumber numberWithBool:YES];
    no = [NSNumber numberWithBool:NO];
    d = [NSMutableDictionary dictionaryWithDictionary:@{
        @kAudioAggregateDeviceNameKey : @"KumoDJ System Audio",
        @kAudioAggregateDeviceUIDKey : [[NSUUID UUID] UUIDString],
        @kAudioAggregateDeviceIsPrivateKey : yes,
        @kAudioAggregateDeviceIsStackedKey : no,
        @kAudioAggregateDeviceTapAutoStartKey : yes,
        @kAudioAggregateDeviceTapListKey : @[ @{ @kAudioSubTapUIDKey : tapUID, @kAudioSubTapDriftCompensationKey : yes } ],
    }];
    [td release];
    /* clock the aggregate from the current output device, like the system does */
    if (ma_get(kAudioObjectSystemObject, kAudioHardwarePropertyDefaultOutputDevice, kAudioObjectPropertyScopeGlobal, &outDev,
               sizeof outDev) &&
        ma_get(outDev, kAudioDevicePropertyDeviceUID, kAudioObjectPropertyScopeGlobal, &outUID, sizeof outUID) && outUID) {
        [d setObject:(NSString *)outUID forKey:@KD_MAIN_SUBDEVICE_KEY];
        [d setObject:@[ @{ @kAudioSubDeviceUIDKey : (NSString *)outUID } ] forKey:@kAudioAggregateDeviceSubDeviceListKey];
        ma_skip = ma_input_buffers(outDev);
        CFRelease(outUID);
    }
    if (AudioHardwareCreateAggregateDevice((CFDictionaryRef)d, &ma_agg) != noErr) return 0;
    ma_get(ma_agg, kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, &rate, sizeof rate);
    if (AudioDeviceCreateIOProcID(ma_agg, ma_ioproc, NULL, &ma_proc) != noErr) return 0;
    if (AudioDeviceStart(ma_agg, ma_proc) != noErr) return 0;
    ma_rate = rate > 8000 ? (int)rate : 48000;
    snprintf(desc, len, "SYSTEM AUDIO TAP %dHZ (SILENT? ALLOW IN PRIVACY)", ma_rate);
    return 1;
}

static void ma_aq_cb(void *ud, AudioQueueRef q, AudioQueueBufferRef b, const AudioTimeStamp *t, UInt32 n,
                     const AudioStreamPacketDescription *pd) {
    float tmp[4096];
    const float *s = (const float *)b->mAudioData;
    UInt32 frames = b->mAudioDataByteSize / 8, i;
    (void)ud; (void)t; (void)n; (void)pd;
    if (frames > 4096) frames = 4096;
    for (i = 0; i < frames; i++) tmp[i] = 0.5f * (s[2 * i] + s[2 * i + 1]);
    rb_push(tmp, (int)frames);
    AudioQueueEnqueueBuffer(q, b, 0, NULL);
}

static int ma_input_open(const char *want, char *desc, int len) {
    AudioStreamBasicDescription f;
    AudioDeviceID dev = 0;
    Float64 rate = 0;
    char name[128] = "DEFAULT INPUT";
    int i;
    if (want) {
        if (!(dev = ma_find_input(want, name, sizeof name))) {
            snprintf(desc, len, "NO INPUT DEVICE MATCHING '%s'", want);
            return 0;
        }
    } else if (ma_get(kAudioObjectSystemObject, kAudioHardwarePropertyDefaultInputDevice, kAudioObjectPropertyScopeGlobal,
                      &dev, sizeof dev)) {
        ma_name(dev, name, sizeof name);
    }
    if (dev) ma_get(dev, kAudioDevicePropertyNominalSampleRate, kAudioObjectPropertyScopeGlobal, &rate, sizeof rate);
    memset(&f, 0, sizeof f);
    f.mSampleRate = rate > 8000 ? rate : 48000;
    f.mFormatID = kAudioFormatLinearPCM;
    f.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
    f.mBitsPerChannel = 32;
    f.mChannelsPerFrame = 2;
    f.mBytesPerFrame = f.mBytesPerPacket = 8;
    f.mFramesPerPacket = 1;
    if (AudioQueueNewInput(&f, ma_aq_cb, NULL, NULL, NULL, 0, &ma_q) != noErr) {
        snprintf(desc, len, "NO AUDIO (CANNOT OPEN INPUT)");
        return 0;
    }
    if (dev) {
        CFStringRef uid = NULL;
        if (ma_get(dev, kAudioDevicePropertyDeviceUID, kAudioObjectPropertyScopeGlobal, &uid, sizeof uid) && uid) {
            AudioQueueSetProperty(ma_q, kAudioQueueProperty_CurrentDevice, &uid, sizeof uid);
            CFRelease(uid);
        }
    }
    for (i = 0; i < 3; i++) {
        AudioQueueBufferRef b;
        if (AudioQueueAllocateBuffer(ma_q, 1024 * 8, &b) == noErr) AudioQueueEnqueueBuffer(ma_q, b, 0, NULL);
    }
    if (AudioQueueStart(ma_q, NULL) != noErr) {
        snprintf(desc, len, "NO AUDIO (INPUT DENIED? CHECK PRIVACY)");
        return 0;
    }
    ma_rate = (int)f.mSampleRate;
    snprintf(desc, len, "INPUT %.40s %dHZ", name, ma_rate);
    return 1;
}

static int plat_audio_open(const Config *c, char *desc, int len) {
    @autoreleasepool {
        if (!desc) {
            printf("input devices (for --device):\n");
            ma_find_input(NULL, NULL, 0);
            return 0;
        }
        if (!c->input && ma_tap_open(desc, len)) return ma_rate;
        if (ma_input_open(c->device, desc, len)) {
            if (!c->input) fprintf(stderr, "kumodj: system-audio tap needs macOS 14.2+; using %s\n", desc);
            return ma_rate;
        }
    }
    return 0;
}

static int plat_audio_read(float *out, int max) { return rb_pop(out, max); }
static int plat_audio_rate(void) { return ma_rate; }

static void plat_audio_close(void) {
    typedef OSStatus (*DestroyTapFn)(AudioObjectID);
    DestroyTapFn destroyTap = (DestroyTapFn)dlsym(RTLD_DEFAULT, "AudioHardwareDestroyProcessTap");
    if (ma_agg) {
        AudioDeviceStop(ma_agg, ma_proc);
        AudioDeviceDestroyIOProcID(ma_agg, ma_proc);
        AudioHardwareDestroyAggregateDevice(ma_agg);
        ma_agg = 0;
    }
    if (ma_tap && destroyTap) destroyTap(ma_tap);
    ma_tap = 0;
    if (ma_q) { AudioQueueStop(ma_q, true); AudioQueueDispose(ma_q, true); ma_q = 0; }
}

static void plat_shutdown(void) {
    if (m_sleep) IOPMAssertionRelease(m_sleep);
    if (m_activity) [[NSProcessInfo processInfo] endActivity:m_activity];
    [NSOpenGLContext clearCurrentContext];
    [m_win orderOut:nil];
}
