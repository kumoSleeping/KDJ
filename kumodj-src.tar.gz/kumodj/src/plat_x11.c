/* plat_x11.c — Linux: X11 window + GLX 3.3 core context, XRandR monitors,
 * PulseAudio/PipeWire monitor-source capture (libpulse-simple, loaded at runtime). */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/keysym.h>
#include <X11/extensions/Xrandr.h>
#include <GL/glx.h>
#include <pthread.h>
#include <dlfcn.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include "ring.h"

static Display *x_dpy;
static Window x_win;
static GLXContext x_ctx;
static Atom x_wmDelete, x_wmState, x_wmFull;
static Cursor x_blank;
static int x_w = 1280, x_h = 720;
static Monitor x_mons[16];
static int x_nmons;
static Time x_lastClick;

static void plat_console(void) {}
static void plat_args(int *argc, char ***argv) { (void)argc; (void)argv; }
static FILE *plat_fopen(const char *p, const char *m) { return fopen(p, m); }
static void plat_error(const char *msg) { fprintf(stderr, "%s\n", msg); }

static double plat_now(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
}
static void plat_sleep(double s) {
    struct timespec ts;
    if (s <= 0) return;
    ts.tv_sec = (time_t)s;
    ts.tv_nsec = (long)((s - ts.tv_sec) * 1e9);
    nanosleep(&ts, 0);
}

static int plat_init(void) {
    XInitThreads();
    x_dpy = XOpenDisplay(0);
    return x_dpy != 0;
}

static int plat_monitors(Monitor *m, int max) {
    int n = 0, i;
    XRRMonitorInfo *mi = XRRGetMonitors(x_dpy, DefaultRootWindow(x_dpy), True, &n);
    x_nmons = 0;
    for (i = 0; mi && i < n && x_nmons < max && x_nmons < 16; i++) {
        Monitor *o = &x_mons[x_nmons++];
        char *nm = XGetAtomName(x_dpy, mi[i].name);
        o->x = mi[i].x; o->y = mi[i].y; o->w = mi[i].width; o->h = mi[i].height; o->primary = mi[i].primary;
        snprintf(o->name, sizeof o->name, "%s", nm ? nm : "screen");
        if (nm) XFree(nm);
    }
    if (mi) XRRFreeMonitors(mi);
    if (!x_nmons) {
        Monitor *o = &x_mons[x_nmons++];
        memset(o, 0, sizeof *o);
        o->w = DisplayWidth(x_dpy, DefaultScreen(x_dpy));
        o->h = DisplayHeight(x_dpy, DefaultScreen(x_dpy));
        o->primary = 1;
        strcpy(o->name, "screen");
    }
    if (x_nmons == 1) x_mons[0].primary = 1;
    memcpy(m, x_mons, sizeof(Monitor) * x_nmons);
    return x_nmons;
}

static void x_fullscreen_hint(int on) {
    XEvent e;
    memset(&e, 0, sizeof e);
    e.xclient.type = ClientMessage;
    e.xclient.window = x_win;
    e.xclient.message_type = x_wmState;
    e.xclient.format = 32;
    e.xclient.data.l[0] = on ? 1 : 0;
    e.xclient.data.l[1] = (long)x_wmFull;
    e.xclient.data.l[3] = 1;
    XSendEvent(x_dpy, DefaultRootWindow(x_dpy), False, SubstructureRedirectMask | SubstructureNotifyMask, &e);
}

static void plat_place(int mon, int fs) {
    Monitor *m = &x_mons[mon < x_nmons ? mon : 0];
    if (fs) {
        XMoveResizeWindow(x_dpy, x_win, m->x, m->y, m->w, m->h);
        x_fullscreen_hint(1);
    } else {
        x_fullscreen_hint(0);
        XMoveResizeWindow(x_dpy, x_win, m->x + (m->w - 1280) / 2, m->y + (m->h - 720) / 2, 1280, 720);
    }
    XFlush(x_dpy);
}

static int plat_open(int mon, int fs) {
    static const int fbAttr[] = { GLX_X_RENDERABLE, True, GLX_DRAWABLE_TYPE, GLX_WINDOW_BIT, GLX_RENDER_TYPE, GLX_RGBA_BIT,
                                  GLX_RED_SIZE, 8, GLX_GREEN_SIZE, 8, GLX_BLUE_SIZE, 8, GLX_DOUBLEBUFFER, True, None };
    static const int ctxAttr[] = { 0x2091, 3, 0x2092, 3, 0x9126, 1, None }; /* 3.3 core */
    typedef GLXContext (*CCA)(Display *, GLXFBConfig, GLXContext, Bool, const int *);
    typedef void (*SIE)(Display *, GLXDrawable, int);
    typedef int (*SIM)(unsigned);
    int n = 0;
    GLXFBConfig *fbc = glXChooseFBConfig(x_dpy, DefaultScreen(x_dpy), fbAttr, &n);
    XVisualInfo *vi;
    XSetWindowAttributes swa;
    Monitor *m = &x_mons[mon < x_nmons ? mon : 0];
    CCA cca = (CCA)glXGetProcAddressARB((const GLubyte *)"glXCreateContextAttribsARB");
    SIE sie = (SIE)glXGetProcAddressARB((const GLubyte *)"glXSwapIntervalEXT");
    SIM sim = (SIM)glXGetProcAddressARB((const GLubyte *)"glXSwapIntervalMESA");
    char nodata[8] = { 0 };
    XColor black;
    Pixmap bm;
    if (!fbc || !n || !cca) return 0;
    vi = glXGetVisualFromFBConfig(x_dpy, fbc[0]);
    if (!vi) return 0;
    memset(&swa, 0, sizeof swa);
    swa.colormap = XCreateColormap(x_dpy, DefaultRootWindow(x_dpy), vi->visual, AllocNone);
    swa.background_pixel = 0;
    swa.event_mask = KeyPressMask | ButtonPressMask | PointerMotionMask | StructureNotifyMask;
    x_w = fs ? m->w : 1280; x_h = fs ? m->h : 720;
    x_win = XCreateWindow(x_dpy, DefaultRootWindow(x_dpy), fs ? m->x : m->x + (m->w - 1280) / 2,
                          fs ? m->y : m->y + (m->h - 720) / 2, x_w, x_h, 0, vi->depth, InputOutput, vi->visual,
                          CWColormap | CWEventMask | CWBackPixel, &swa);
    XStoreName(x_dpy, x_win, "KumoDJ");
    x_wmDelete = XInternAtom(x_dpy, "WM_DELETE_WINDOW", False);
    x_wmState = XInternAtom(x_dpy, "_NET_WM_STATE", False);
    x_wmFull = XInternAtom(x_dpy, "_NET_WM_STATE_FULLSCREEN", False);
    XSetWMProtocols(x_dpy, x_win, &x_wmDelete, 1);
    if (fs) XChangeProperty(x_dpy, x_win, x_wmState, XA_ATOM, 32, PropModeReplace, (unsigned char *)&x_wmFull, 1);
    XMapRaised(x_dpy, x_win);
    x_ctx = cca(x_dpy, fbc[0], 0, True, ctxAttr);
    XFree(fbc);
    XFree(vi);
    if (!x_ctx || !glXMakeCurrent(x_dpy, x_win, x_ctx)) return 0;
    if (sie) sie(x_dpy, x_win, 1); else if (sim) sim(1);
    bm = XCreateBitmapFromData(x_dpy, x_win, nodata, 8, 8);
    memset(&black, 0, sizeof black);
    x_blank = XCreatePixmapCursor(x_dpy, bm, bm, &black, &black, 0, 0);
    XFreePixmap(x_dpy, bm);
    XSelectInput(x_dpy, DefaultRootWindow(x_dpy), StructureNotifyMask);
    XRRSelectInput(x_dpy, DefaultRootWindow(x_dpy), RRScreenChangeNotifyMask);
    return 1;
}

static void plat_pump(void) {
    while (XPending(x_dpy)) {
        XEvent e;
        XNextEvent(x_dpy, &e);
        if (e.type == KeyPress) {
            KeySym ks = XLookupKeysym(&e.xkey, 0);
            int k = 0;
            if (ks >= XK_a && ks <= XK_z) k = (int)ks;
            else if (ks >= XK_0 && ks <= XK_9) k = (int)ks;
            else switch (ks) {
                case XK_Escape: k = K_ESC; break;
                case XK_Return: k = K_ENTER; break;
                case XK_space: k = ' '; break;
                case XK_Left: k = K_LEFT; break;
                case XK_Right: k = K_RIGHT; break;
                case XK_Up: k = K_UP; break;
                case XK_Down: k = K_DOWN; break;
                case XK_F11: k = K_F11; break;
                case XK_Tab: k = K_TAB; break;
                case XK_bracketleft: k = '['; break;
                case XK_bracketright: k = ']'; break;
                }
            if (k) ev_push(EV_KEY, k);
        } else if (e.type == ButtonPress && e.xbutton.button == 1) {
            if (e.xbutton.time - x_lastClick < 400) ev_push(EV_DBLCLICK, 0);
            x_lastClick = e.xbutton.time;
        } else if (e.type == MotionNotify) {
            ev_push(EV_MOUSE, 0);
        } else if (e.type == ConfigureNotify && e.xconfigure.window == x_win) {
            x_w = e.xconfigure.width; x_h = e.xconfigure.height;
        } else if (e.type == ClientMessage && (Atom)e.xclient.data.l[0] == x_wmDelete) {
            ev_push(EV_QUIT, 0);
        } else if (e.type == ConfigureNotify || e.type >= LASTEvent) {
            XRRUpdateConfiguration(&e);
            if (e.type != ConfigureNotify) ev_push(EV_DISPLAYS, 0);
        }
    }
}

static void plat_drawable(int *w, int *h) { *w = x_w; *h = x_h; }
static void plat_swap(void) { glXSwapBuffers(x_dpy, x_win); }
static void *plat_glproc(const char *name) { return (void *)glXGetProcAddressARB((const GLubyte *)name); }
static void plat_cursor(int visible) {
    if (visible) XUndefineCursor(x_dpy, x_win); else XDefineCursor(x_dpy, x_win, x_blank);
    XFlush(x_dpy);
}

/* ---- audio: PulseAudio simple API on the default sink's monitor ---- */
typedef struct { int format; uint32_t rate; uint8_t channels; } kd_pa_spec;
typedef struct { uint32_t maxlength, tlength, prebuf, minreq, fragsize; } kd_pa_attr;
static void *(*pa_new)(const char *, const char *, int, const char *, const char *, const kd_pa_spec *, const void *,
                       const kd_pa_attr *, int *);
static int (*pa_read)(void *, void *, size_t, int *);
static void (*pa_free)(void *);
static void *x_pa;
static volatile int x_audioRun;
static pthread_t x_thread;

static void *x_audio_thread(void *arg) {
    float buf[480];
    (void)arg;
    while (x_audioRun) {
        int err;
        if (pa_read(x_pa, buf, sizeof buf, &err) < 0) break;
        rb_push(buf, 480);
    }
    return 0;
}

static int plat_audio_open(const Config *c, char *desc, int len) {
    void *lib;
    kd_pa_spec ss = { 5 /* PA_SAMPLE_FLOAT32LE */, 48000, 1 };
    kd_pa_attr at = { (uint32_t)-1, (uint32_t)-1, (uint32_t)-1, (uint32_t)-1, 480 * 4 };
    int err = 0;
    const char *dev = c->device ? c->device : "@DEFAULT_MONITOR@";
    if (!desc) return 0;
    if (!(lib = dlopen("libpulse-simple.so.0", RTLD_NOW))) { snprintf(desc, len, "NO AUDIO (LIBPULSE-SIMPLE MISSING)"); return 0; }
    pa_new = (void *(*)(const char *, const char *, int, const char *, const char *, const kd_pa_spec *, const void *,
                        const kd_pa_attr *, int *))dlsym(lib, "pa_simple_new");
    pa_read = (int (*)(void *, void *, size_t, int *))dlsym(lib, "pa_simple_read");
    pa_free = (void (*)(void *))dlsym(lib, "pa_simple_free");
    if (!pa_new || !pa_read || !pa_free) { snprintf(desc, len, "NO AUDIO (LIBPULSE-SIMPLE BROKEN)"); return 0; }
    if (!(x_pa = pa_new(0, "kumodj", 2 /* PA_STREAM_RECORD */, dev, "visuals", &ss, 0, &at, &err))) {
        snprintf(desc, len, "NO AUDIO (PULSEAUDIO ERROR %d)", err);
        return 0;
    }
    x_audioRun = 1;
    pthread_create(&x_thread, 0, x_audio_thread, 0);
    snprintf(desc, len, "PULSE %.40s", dev);
    return 48000;
}
static int plat_audio_read(float *out, int max) { return rb_pop(out, max); }
static int plat_audio_rate(void) { return x_pa ? 48000 : 0; }
static void plat_audio_close(void) {
    if (x_pa) { x_audioRun = 0; pthread_join(x_thread, 0); pa_free(x_pa); x_pa = 0; }
}
static void plat_shutdown(void) {
    if (x_ctx) { glXMakeCurrent(x_dpy, None, 0); glXDestroyContext(x_dpy, x_ctx); }
    if (x_win) XDestroyWindow(x_dpy, x_win);
    XCloseDisplay(x_dpy);
}
