/* ring.h — lock-free single-producer/single-consumer sample ring used by the
 * macOS and Linux backends (audio callback thread → render thread). */
#ifndef KD_RING_H
#define KD_RING_H
#define RB_N 65536
static float rb_buf[RB_N];
static unsigned rb_w, rb_r;

static void rb_push(const float *x, int n) {
    unsigned w = __atomic_load_n(&rb_w, __ATOMIC_RELAXED), r = __atomic_load_n(&rb_r, __ATOMIC_ACQUIRE);
    int i;
    for (i = 0; i < n && w - r < RB_N; i++) rb_buf[w++ & (RB_N - 1)] = x[i];
    __atomic_store_n(&rb_w, w, __ATOMIC_RELEASE);
}

static int rb_pop(float *x, int max) {
    unsigned r = __atomic_load_n(&rb_r, __ATOMIC_RELAXED), w = __atomic_load_n(&rb_w, __ATOMIC_ACQUIRE);
    int n = 0;
    while (r != w && n < max) x[n++] = rb_buf[r++ & (RB_N - 1)];
    __atomic_store_n(&rb_r, r, __ATOMIC_RELEASE);
    return n;
}
#endif
