// Shadertoy-format shader: kumodj detects mainImage() and maps
// iResolution, iTime, iChannel0 (audio: FFT row at y=.25, waveform at y=.75), iChannel1 (last frame).
void mainImage(out vec4 fragColor, in vec2 fragCoord)
{
    vec2 uv = fragCoord / iResolution.xy;
    float fft = texture(iChannel0, vec2(uv.x, 0.25)).x;
    float wave = texture(iChannel0, vec2(uv.x, 0.75)).x;
    vec3 col = vec3(0.1, 0.6, 1.0) * step(uv.y, fft);
    col += vec3(1.0, 0.3, 0.6) * smoothstep(0.01, 0.0, abs(uv.y - 0.5 - wave * 0.25));
    fragColor = vec4(col, 1.0);
}
