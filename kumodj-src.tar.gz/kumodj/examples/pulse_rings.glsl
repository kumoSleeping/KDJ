// kumodj-native style: the prelude gives you uniforms + helpers, write fragColor.
//   BASS LOWMID MID HIGH   band energy 0..1          KICK SNARE HAT DROP  hit pulses 1->0
//   BEAT  beat pulse on the tempo grid   PHASE 0..1 within the beat   BAR 0..1 within the bar
//   LEVEL ENERGY GROOVE (tempo lock 0..1)   uTime  uMTime (music time: speeds up with energy)
//   pal(t) palette colour   spec(x) wave(x) peak(x) spectrum/waveform   prevc(p) previous frame
//   cuv() centred coords (y in -.5..5)   suv() 0..1 coords
void main(){
    vec2 p = cuv();
    float r = length(p);
    float rings = sin(r * 40.0 - uMTime * 6.0) * 0.5 + 0.5;
    float band = spec(fract(r * 1.5));
    vec3 c = pal(r + BAR * 0.5) * pow(rings, 8.0 - 6.0 * KICK) * (0.2 + 1.8 * band);
    c += pal(0.5) * exp(-r * 10.0) * BEAT;
    fragColor = vec4(c + prevc(p * 0.98) * 0.7, 1.0);
}
