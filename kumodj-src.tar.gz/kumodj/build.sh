#!/bin/sh
# Build kumodj.
#   ./build.sh          build for this machine; also the Windows .exe if mingw-w64 is installed
#   ./build.sh win      only cross-compile the Windows .exe (needs x86_64-w64-mingw32-gcc)
# Outputs go to build/.  No dependencies beyond the OS SDK.
set -e
cd "$(dirname "$0")"
mkdir -p build

build_win() {
    # note: no -fdata-sections — with it mingw moves zero-initialised statics from .bss into .data (+140 KB)
    x86_64-w64-mingw32-gcc -std=gnu11 -Os -Wall -Wno-format-truncation -D__USE_MINGW_ANSI_STDIO=0 -mwindows \
        -fno-asynchronous-unwind-tables -ffunction-sections -Wl,--gc-sections -s \
        -o build/kumodj.exe src/kumodj.c -lopengl32 -lgdi32 -lole32 -lshell32 -luser32
    echo "built build/kumodj.exe ($(wc -c < build/kumodj.exe) bytes)"
}

build_mac() {
    clang -x objective-c -std=gnu11 -Os -Wall -fno-objc-arc -arch arm64 -arch x86_64 -mmacosx-version-min=11.0 \
        -o build/kumodj src/kumodj.c \
        -framework Cocoa -framework OpenGL -framework CoreAudio -framework AudioToolbox -framework IOKit \
        -Wl,-sectcreate,__TEXT,__info_plist,res/Info.plist -Wl,-dead_strip
    strip -x build/kumodj
    codesign -s - -f build/kumodj
    app=build/KumoDJ.app
    rm -rf "$app"
    mkdir -p "$app/Contents/MacOS"
    cp res/Info.plist "$app/Contents/Info.plist"
    cp build/kumodj "$app/Contents/MacOS/kumodj"
    codesign -s - -f "$app"
    echo "built build/kumodj ($(wc -c < build/kumodj) bytes, universal) and build/KumoDJ.app"
}

build_linux() {
    ${CC:-cc} -std=gnu11 -Os -Wall -Wno-format-truncation -ffunction-sections -Wl,--gc-sections -s \
        -o build/kumodj src/kumodj.c -lX11 -lXrandr -lGL -ldl -lpthread -lm
    echo "built build/kumodj ($(wc -c < build/kumodj) bytes)"
}

if [ "$1" = win ]; then build_win; exit; fi
case "$(uname -s)" in
    Darwin) build_mac ;;
    Linux) build_linux ;;
    *) echo "unsupported host; on Windows use build.bat" >&2; exit 1 ;;
esac
if command -v x86_64-w64-mingw32-gcc >/dev/null 2>&1; then build_win; fi
