@echo off
rem Build build\kumodj.exe on Windows.
rem Uses MSVC when run from a "Developer Command Prompt for VS", otherwise gcc
rem (w64devkit / MSYS2 mingw64) from PATH.
setlocal
cd /d "%~dp0"
if not exist build mkdir build

where cl >nul 2>nul
if %errorlevel%==0 (
    cl /nologo /std:c11 /O1 /GS- /W1 /D_CRT_SECURE_NO_WARNINGS src\kumodj.c /Fe:build\kumodj.exe /Fo:build\ ^
       /link /SUBSYSTEM:WINDOWS /ENTRY:mainCRTStartup /OPT:REF /OPT:ICF ^
       opengl32.lib gdi32.lib user32.lib ole32.lib shell32.lib
    if errorlevel 1 exit /b 1
    goto done
)
where gcc >nul 2>nul
if %errorlevel%==0 (
    gcc -std=gnu11 -Os -D__USE_MINGW_ANSI_STDIO=0 -mwindows -fno-asynchronous-unwind-tables -ffunction-sections ^
        -Wl,--gc-sections -s -o build\kumodj.exe src\kumodj.c -lopengl32 -lgdi32 -lole32 -lshell32 -luser32
    if errorlevel 1 exit /b 1
    goto done
)
echo No C compiler found: install "Build Tools for Visual Studio" or w64devkit, then run this again.
exit /b 1

:done
echo built build\kumodj.exe
