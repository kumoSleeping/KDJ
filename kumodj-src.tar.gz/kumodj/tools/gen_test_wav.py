#!/usr/bin/env python3
"""Synthesise test tracks for the beat tracker: kick/snare/hats/bass/pads with an
intro, breakdown and drop.  Writes 16-bit mono WAV + a .beats file of true beat times.

usage: gen_test_wav.py OUT.wav BPM [seconds] [--swing] [--no-kick-intro] [--sr 48000]
"""
import sys, wave, numpy as np

def main():
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    flags = [a for a in sys.argv[1:] if a.startswith('--')]
    out, bpm = args[0], float(args[1])
    dur = float(args[2]) if len(args) > 2 else 40.0
    sr = 48000
    for f in flags:
        if f.startswith('--sr='): sr = int(f[5:])
    rng = np.random.default_rng(int(bpm * 10))
    n = int(dur * sr)
    t = np.arange(n) / sr
    y = np.zeros(n)
    spb = 60.0 / bpm
    beats = np.arange(0, dur, spb)
    nb = len(beats)
    # structure (in beats): 0-32 full, 32-48 breakdown (no kick/bass), 48- drop
    def section(i):
        if 32 <= i < 48: return 'break'
        return 'full'

    def add(sig, start):
        s = int(start * sr)
        if s >= n: return
        e = min(n, s + len(sig))
        y[s:e] += sig[:e - s]

    kl = int(0.35 * sr); kt = np.arange(kl) / sr
    kick = np.sin(2 * np.pi * (45 * kt + 120 * (1 - np.exp(-kt * 30)) / 30)) * np.exp(-kt * 9) * 0.9
    sl = int(0.2 * sr); st = np.arange(sl) / sr
    snare = (rng.standard_normal(sl) * 0.5 + np.sin(2 * np.pi * 190 * st) * 0.5) * np.exp(-st * 22) * 0.45
    hl = int(0.05 * sr); ht = np.arange(hl) / sr
    hat = np.diff(rng.standard_normal(hl + 1)) * np.exp(-ht * 90) * 0.12
    swing = 0.08 * spb if '--swing' in flags else 0.0

    for i, b in enumerate(beats):
        sec = section(i)
        if sec == 'full':
            add(kick, b)
            if i % 2 == 1: add(snare, b)
            # bass: offbeat eighth notes
            bl = int(spb / 2 * sr); btt = np.arange(bl) / sr
            f = [55, 55, 65.4, 49][(i // 4) % 4]
            add(np.sign(np.sin(2 * np.pi * f * btt)) * 0.18 * np.exp(-btt * 6), b + spb / 2)
        for h in range(2):
            add(hat * (1.0 if h else 0.6), b + h * spb / 2 + (swing if h else 0))
    # pads: chord every 4 beats (always, gives harmonic content during breakdown)
    for i in range(0, nb, 4):
        root = [220, 196, 174.6, 196][(i // 4) % 4]
        pl = int(4 * spb * sr); pt = np.arange(pl) / sr
        env = np.minimum(1, pt * 8) * np.exp(-pt * 0.4)
        pad = sum(np.sin(2 * np.pi * root * r * pt) for r in (1, 1.26, 1.5, 2.0)) * 0.05 * env
        add(pad, beats[i])
    y += rng.standard_normal(n) * 0.003
    y = y / max(1e-9, np.abs(y).max()) * 0.8
    with wave.open(out, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((y * 32767).astype('<i2').tobytes())
    with open(out.rsplit('.', 1)[0] + '.beats', 'w') as f:
        f.write('\n'.join('%.5f' % b for b in beats))

main()
