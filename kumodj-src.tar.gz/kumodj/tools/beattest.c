/* beattest — run kumodj's analyzer offline over a WAV file and report tempo,
 * confidence and how well beat-clock crossings line up with the true beats.
 * build: cc -O2 -o beattest tools/beattest.c -lm
 * usage: beattest file.wav [file.beats] */
#include <stdio.h>
#include <stdlib.h>
#include "../src/analysis.h"
#include "../src/wav.h"

static Analyzer an;

int main(int argc, char **argv) {
    int n, rate, i, lastIdx = 0, nb = 0, ncross = 0, kicks = 0, drops = 0;
    float *x;
    double *tb = 0, err = 0, err2 = 0, octaveOk = 0;
    int nerr = 0;
    if (argc < 2) { fprintf(stderr, "usage: beattest file.wav [file.beats]\n"); return 1; }
    x = wav_load(argv[1], &n, &rate);
    if (!x) { fprintf(stderr, "cannot read %s\n", argv[1]); return 1; }
    if (argc > 2) {
        FILE *f = fopen(argv[2], "r");
        double v;
        tb = malloc(sizeof(double) * 100000);
        while (f && fscanf(f, "%lf", &v) == 1) tb[nb++] = v;
        if (f) fclose(f);
    }
    an_init(&an, (float)rate);
    for (i = 0; i + 480 <= n; i += 480) {
        unsigned kc = an.kick.count;
        double t, bt;
        an_feed(&an, x + i, 480);
        t = (double)(i + 480) / rate;
        if (an.kick.count != kc) kicks++;
        if (an.dropCount != (unsigned)drops) { drops = an.dropCount; printf("  drop at %.2fs\n", t); }
        bt = an_beat_now(&an);
        if ((int)floor(bt) > lastIdx) {
            /* crossing happened (1 - frac) beats ago */
            double ct = t - (bt - floor(bt)) / an_bps(&an);
            lastIdx = (int)floor(bt);
            ncross++;
            if (nb && t > 12 && an.conf > 0.2f) { /* after lock-in */
                int j; double best = 1e9, spb = tb[1] - tb[0];
                for (j = 0; j < nb; j++) if (fabs(ct - tb[j]) < fabs(best)) best = ct - tb[j];
                if (fabs(best) < spb * 0.25) { err += best; err2 += best * best; nerr++; }
            }
        }
        if (i % (rate * (t < 8 ? 1 : 4)) < 480)
            printf("t=%5.1fs bpm=%6.2f conf=%.2f down=%d int=%.2f lvl=%.2f bass=%.2f bd=%d\n", t,
                   60.f * an_bps(&an), an.conf, an.downbeat, an.intensity, an.level, an.bandS[0], an.breakdown);
    }
    printf("kicks=%d crossings=%d drops=%d\n", kicks, ncross, drops);
    if (nb > 1) {
        double spb = tb[1] - tb[0], bpm = 60.0 / spb, got = 60.0 * an_bps(&an), r = got / bpm;
        octaveOk = fabs(r - 1) < 0.02 || fabs(r - 2) < 0.04 || fabs(r - 0.5) < 0.01;
        printf("RESULT true=%.2f got=%.2f %s  phase: n=%d mean=%+.1fms sd=%.1fms\n", bpm, got,
               octaveOk ? "OK" : "WRONG", nerr, nerr ? 1000 * err / nerr : 0,
               nerr ? 1000 * sqrt(err2 / nerr - (err / nerr) * (err / nerr)) : 0);
    }
    return 0;
}
