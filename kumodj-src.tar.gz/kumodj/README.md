# KumoDJ — 迷你实时音频可视化 VJ

一个 **~65 KB** 的单文件程序：实时抓取电脑正在播放的声音，跟踪节拍、小节、drop，用 GPU 着色器生成随音乐律动的画面，启动后**自动占领外接屏幕并全屏播放**。无依赖、无安装、无运行库。

![styles](docs/styles.jpg)

## 特性

- **抓系统声音，不用麦克风**：Windows 用 WASAPI loopback（默认输出设备，切换设备/插拔耳机自动跟随）；macOS 14.2+ 用 Core Audio process tap；更老的 macOS 可用 BlackHole 等输入设备；Linux 用 PulseAudio/PipeWire monitor。
- **真正的节拍跟踪**：频谱通量起音检测 → 自相关测速（78–160 BPM，更快的曲子自动折半）→ PLL 锁相的节拍时钟，可**预判**下一拍（补偿声卡/显示延迟）。另有 kick / snare / hi-hat 独立触发、小节首拍估计、breakdown→drop 检测。
- **自动 VJ**：每 N 小节在拍点上切换风格（默认 16 小节），drop 时闪白并立刻切换，调色板按乐句轮换；没有节奏的段落（ambient）节拍脉冲自动淡出。
- **10 种风格 × 9 套调色板**，外加自定义 GLSL（兼容 Shadertoy 的 `mainImage` 写法）。
- **外接屏幕优先**：启动时自动选择第一个非主屏幕（投影仪/LED/第二显示器）无边框全屏；热插拔后自动迁移；`M` 键在屏幕间移动。
- **性能**：音频分析约占单核 0.5%；渲染是每帧 1 个场景 pass + 1 个后期 pass（反馈拖影、mip bloom、节拍缩放、色散、暗角）；4K 屏幕默认以 ≤1080p 内部分辨率渲染再放大；vsync 驱动，不空转。防止屏保/休眠。

## 获取

| 平台 | 构建 | 产物 |
|---|---|---|
| Windows 10/11 | `build.bat`（VS 开发者命令行里用 MSVC，或 PATH 中有 gcc 如 w64devkit）<br>或在 Linux/macOS 上 `./build.sh win`（mingw-w64 交叉编译） | `build\kumodj.exe` ≈ 65 KB |
| macOS 11+ | 先装编译工具 `xcode-select --install`，再在项目目录运行 `sh build.sh` | `build/KumoDJ.app` + `build/kumodj`（arm64+x86_64 通用二进制） |
| Linux | `./build.sh`（需要 `libx11-dev libxrandr-dev libgl-dev`） | `build/kumodj` ≈ 62 KB |

`.github/workflows/build.yml` 可在 GitHub Actions 上一次构建三个平台。

## 使用

直接运行即可：有外接屏就去外接屏全屏，没有就在主屏全屏。播放任何音乐（Spotify、网易云、浏览器、DJ 软件…）画面就会动起来。

```
kumodj --list            列出屏幕（macOS 还列出输入设备）
kumodj -m 2              指定第 2 块屏幕
kumodj -w                窗口模式
kumodj -s synth -p vapor 固定风格/调色板（关闭自动切换，按 A 可再打开）
kumodj --bars 8          每 8 小节自动换一次风格
kumodj --latency 80      画面提前 80ms（蓝牙音箱之类延迟大时调大）
kumodj --shader my.glsl  加载自定义着色器
kumodj --help            全部参数
```

### 快捷键

| 键 | 功能 | 键 | 功能 |
|---|---|---|---|
| `1`–`9`, `0` | 选风格 1–10 | `←` `→` / 空格 | 上一个 / 下一个风格 |
| `C` | 下一套调色板 | `A` | 自动 VJ 开/关 |
| `T` | Tap tempo（跟着拍子连按；按一下=对齐相位） | `[` `]` | 延迟补偿 −/+ 10ms |
| `↑` `↓` | 反应强度 0.2–3 | `B` | 黑场（淡出/淡入） |
| `S` | 频闪（**光敏性癫痫警告**，默认关，限制 ≤3Hz） | `H` / Tab | 常驻显示 HUD（BPM、锁定度、延迟、FPS） |
| `F` / F11 / 双击 / Alt+Enter | 全屏切换 | `M` | 移到下一块屏幕 |
| `R` | 重新加载自定义着色器 | `Esc` | 退出全屏（窗口模式下退出） |
| `Q` / ⌘Q | 退出 | | |

### 风格

| # | 名称 | 画面 | 主要驱动 |
|---|---|---|---|
| 1 | TUNNEL | 多边形霓虹隧道 | 每一环对应一个频段；kick 加粗光环 |
| 2 | HALO | 镜像环形频谱 + 缩放拖影 | 频谱柱、低频推动缩放、snare 旋转 |
| 3 | LIQUID | 域扭曲流体 | 低音控制扭曲深度，hi-hat 闪粒 |
| 4 | KALEIDO | 万花筒 + 反馈管 | 频谱控制圆环尺寸，每 4 小节换对称数 |
| 5 | SYNTH | 合成波网格 + 条纹太阳 + 频谱山脉 | kick 点亮网格，低音推太阳 |
| 6 | WARP | 超空间星轨 | 能量/kick 决定速度与拖尾 |
| 7 | SCOPE | 示波器波形（线/环）+ 回声 | 实时波形 |
| 8 | GYROID | 光线步进的 gyroid 隧道飞行 | 低音加厚曲面，kick 光带 |
| 9 | EQ | 经典镜像 LED 频谱 + 峰值帽 | 频谱 |
| 10 | CELLS | 流动 Voronoi 细胞 | 细胞随频段发光，kick 随机点亮 |

调色板：NEON SUNSET ICE ACID VAPOR FIRE OCEAN MATRIX MONO。

## 自定义着色器

`--shader 文件` 会把它加入风格列表并作为起始风格；改完按 `R` 热重载，编译错误打印在终端且不影响运行。两种写法都支持（见 `examples/`）：

- **kumodj 原生**：直接写 `void main()`，输出 `fragColor`。可用：`BASS LOWMID MID HIGH`（频段 0–1）、`KICK SNARE HAT DROP`（触发脉冲 1→0）、`BEAT`（节拍网格脉冲）、`PHASE`（拍内相位 0–1）、`BAR`（小节内相位 0–1）、`LEVEL ENERGY GROOVE`、`uTime`、`uMTime`（随能量加速的"音乐时间"）、`pal(t)` 当前调色板、`spec(x) peak(x) wave(x)`、`prevc(p)` 上一帧（反馈）、`cuv()`/`suv()` 坐标。
- **Shadertoy**：含 `mainImage()` 时自动映射 `iResolution iTime iChannel0 iChannel1`。`iChannel0` 是音频纹理，与 Shadertoy 的音频输入布局一致（y=0.25 频谱、y=0.75 波形），很多 Shadertoy 音频作品可直接用；`iChannel1` 是上一帧。

## macOS 说明

- 首次运行会请求 **"系统录音"(System Audio Recording)** 权限。建议用 `KumoDJ.app` 启动（从终端直接跑二进制时，权限归属于终端 App）。若 HUD 显示在听系统声音但画面不动：系统设置 → 隐私与安全性 → 录屏与系统录音 → 允许 KumoDJ（或你的终端）。
- macOS 11–14.1 没有 process tap：安装 [BlackHole](https://github.com/ExistentialAudio/BlackHole) 并建立"多输出设备"，然后 `kumodj --device blackhole`。
- 渲染用 OpenGL（Apple 已标记弃用但在 Apple Silicon 上仍然可用），全屏在外接屏时覆盖该屏菜单栏；在主屏时隐藏菜单栏和 Dock。

## 延迟校准

画面比声音晚？按 `]` 让画面提前；画面抢拍？按 `[`。默认 +40ms 适合有线音箱/HDMI；蓝牙耳机/音箱通常要 +150～250ms。也可以跟着拍子按几下 `T` 强制对齐。

## 原理（简）

```
系统音频 ─► 单声道 ─► FFT 2048 / hop 512 (~94Hz)
             ├─► 对数频谱 256 bin + 峰值保持 + 波形 ──► 音频纹理 (RGBA16F 256×2)
             ├─► 4 个频段能量（各自 AGC）
             ├─► 对数谱通量 ─► kick / snare / hat 自适应阈值触发
             └─► 起音函数 ─► 自相关 + 多倍频梳 + 120BPM 先验 ─► 周期
                              └─► 梳状相位匹配 ─► PLL 节拍时钟 ─► +延迟前瞻 ─► 拍/小节/drop
导演（auto VJ）：在小节边界切风格、drop 立刻切、换调色板
渲染：场景着色器 (RGBA16F ping-pong 反馈) ─► mipmap ─► 后期（缩放冲击/故障切换/色散/bloom/色调映射/HUD）
```

合成测试集上（`tools/`），128/140/122/100(swing)/90/174 BPM 全部测对（174 折半为 87），拍点相位抖动 1–12ms，breakdown 后的 drop 全部检出；噪声与无节奏铺底的锁定度 ≤6%。

```
python3 tools/gen_test_wav.py t.wav 128 && cc -O2 -o beattest tools/beattest.c -lm && ./beattest t.wav t.beats
```

## 文件

```
src/kumodj.c      主程序：参数、导演、渲染、HUD、主循环（单一编译单元）
src/analysis.h    音频分析（FFT、频段、起音、测速、PLL）
src/shaders.h     全部 GLSL（前导、10 个风格、后期）与调色板
src/plat_win32.c  Win32 + WGL + WASAPI loopback
src/plat_mac.m    Cocoa + NSOpenGL + Core Audio tap / AudioQueue
src/plat_x11.c    X11 + GLX + PulseAudio
src/gl.h font.h wav.h ring.h
examples/         自定义着色器示例
tools/            节拍跟踪测试（合成音轨 + 离线评估）
```
